# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "DayZ Modding Tools",
    "description": "",
    "author": "Zelik",
    "version": (0, 2, 4),
    "blender": (2, 92, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
dayz_modding_tools = {
    "show_obj_type": True, 
    "show_create_obj": False, 
    "show_create_mem_lod": False, 
    "show_create_mem_points": False, 
    "show_create_geo_lod": False, 
    "show_button_combine_geo": False, 
    "show_finalize": False, 
    }
functions = {
    "dz_mem_point_name": "", 
    "dz_mem_points": [], 
    "dz_list_of_survivor_bones": [], 
    "dz_list_of_hidden_selections": [], 
    "dz_list_of_materials": [], 
    "dz_p": "P:\\", 
    "dz_data": "\\data", 
    "dz_slash": "\\", 
    "pz_quotes": "\"", 
    "dz_cfg_name": "", 
    }
operators = {
    "dz_rvmat_create": True, 
    "dz_cfg_create": True, 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   DayZ Modding Tools
def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc


#######   Functions
def dzf_create_mem_point(name, ):
    try:
        functions["dz_mem_point_name"] = sn_cast_string(name)
        functions["dz_mem_points"].append(functions["dz_mem_point_name"])
        pass # DZS_Create_Mem_Point.py Script Start
        import bpy
        # get the current scene
        scn = bpy.context.scene
        # create a mesh data block
        mymesh = bpy.data.meshes.new(functions["dz_mem_point_name"])
        # define some vertices
        verts = [Vector((0,  0, 0))]
        edges = []
        faces = []
        # add the vertices to the mesh
        mymesh.from_pydata(verts, edges, faces)
        # create an object that uses the mesh data
        myobj = bpy.data.objects.new(functions["dz_mem_point_name"], mymesh)
        # link the object to the scene
        scn.collection.objects.link(myobj)
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.scene.objects[myobj.name].select_set(True)
        bpy.context.view_layer.objects.active = bpy.data.objects[myobj.name]
        box_verts = [vert.co for vert in myobj.data.vertices]
        vertexgroup = bpy.context.active_object.vertex_groups.new(name=myobj.name)
        vertex = [0]
        vertexgroup.add(vertex, 1.0, 'ADD')
        pass # DZS_Create_Mem_Point.py Script End
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Create_Mem_Point")

def dzf_create_invview_camera():
    try:
        pass # DZS_Create_Invview_Camera.py Script Start
        scn = bpy.context.scene
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                override = bpy.context.copy()
                override['area'] = area
                bpy.ops.view3d.view_axis(override, type='TOP')
                break
        # create the first camera
        cam = bpy.data.cameras.new("invview camera")
        cam.lens = 10
        # create the first camera object
        cam_obj = bpy.data.objects.new("invview camera", cam)
        cam_obj.location = (0, -5, 5)
        cam_obj.rotation_euler = (45, 0, 0)
        scn.collection.objects.link(cam_obj)
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.view_layer.objects.active = bpy.data.objects[cam_obj.name]
        bpy.context.scene.objects[cam_obj.name].select_set(True)
        pass # DZS_Create_Invview_Camera.py Script End
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Create_Invview_Camera")

def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc

def dzf_skip(current, next, ):
    try:
        try: exec(r"dayz_modding_tools[':::::'] = False".replace(r":::::", sn_cast_string(current)))
        except Exception as exc: sn_handle_script_line_exception(exc, r"dayz_modding_tools[':::::'] = False".replace(r":::::", sn_cast_string(current)))
        try: exec(r"dayz_modding_tools[':::::'] = True".replace(r":::::", sn_cast_string(next)))
        except Exception as exc: sn_handle_script_line_exception(exc, r"dayz_modding_tools[':::::'] = True".replace(r":::::", sn_cast_string(next)))
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Skip")

def dzf_create_hidden_selections():
    try:
        pass # DZS_Create_Hidden_Selections.py Script Start
        import bpy
        sections = ""
        Tabs = "\t\t\t"
        mats = bpy.data.materials
        if bpy.context.scene.dz_object_subtype == 'Inventory Base':
            obj = bpy.context.scene.objects["0"]
            bpy.context.view_layer.objects.active = obj
            obj.select_set(True)            
        if bpy.context.scene.dz_object_subtype == 'Melee Weapon':
            obj = bpy.context.scene.objects["View Pilot"]
            bpy.context.view_layer.objects.active = obj
            obj.select_set(True)
        filename = 'HiddenSelections'
        if filename not in bpy.data.texts:
            bpy.data.texts.new(filename)
            area = next(area for area in bpy.context.screen.areas if area.type == 'TEXT_EDITOR')
            area.spaces.active.text = bpy.data.texts['HiddenSelections']
            bpy.data.texts[filename].write("\t\thiddenSelections[]=\n")
            bpy.data.texts[filename].write("\t\t{\n")
            list = functions["dz_list_of_hidden_selections"]
            count = 0
            for i in list:
                count += 1
            for i in list:
                if count > 1:
                    bpy.data.texts[filename].write(Tabs + "\"" + i + "\"," + '\n')
                if count == 1:
                    bpy.data.texts[filename].write(Tabs + "\"" + i + "\"")
                count -= 1
            bpy.data.texts[filename].write("\n")
            bpy.data.texts[filename].write("\t\t};\n")
            bpy.data.texts[filename].write("\t\thiddenSelectionsTextures[]=\n")
            bpy.data.texts[filename].write("\t\t{\n")
            list = functions["dz_list_of_materials"]
            count = 0
            for i in list:
                count += 1
            for i in list:
                str = ""
                if count > 1:
                    bpy.data.texts[filename].write(Tabs + "\"" + mats[i.name].armaMatProps.texture + "\"," + '\n')
                if count == 1:
                    bpy.data.texts[filename].write(Tabs + "\"" + mats[i.name].armaMatProps.texture + "\"")
                count -= 1        
            bpy.data.texts[filename].write("\n")
            bpy.data.texts[filename].write("\t\t};\n") 
        pass # DZS_Create_Hidden_Selections.py Script End
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Create_Hidden_Selections")

def dzf_select(name, ):
    try:
        print(r"obj = bpy.context.scene.objects[':::::']".replace(r":::::", sn_cast_string(name)))
        try: exec(r"obj = bpy.context.scene.objects[':::::']".replace(r":::::", sn_cast_string(name)))
        except Exception as exc: sn_handle_script_line_exception(exc, r"obj = bpy.context.scene.objects[':::::']".replace(r":::::", sn_cast_string(name)))
        try: exec(r"obj.select_set(True)")
        except Exception as exc: sn_handle_script_line_exception(exc, r"obj.select_set(True)")
        try: exec(r"bpy.context.view_layer.objects.active = obj")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.view_layer.objects.active = obj")
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Select")

def dzf_deselect():
    try:
        try: exec(r"bpy.ops.object.select_all(action='DESELECT')")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.select_all(action='DESELECT')")
        try: exec(r"bpy.context.view_layer.objects.active = None")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.context.view_layer.objects.active = None")
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Deselect")

def dzf_finish_geo_lod():
    try:
        pass # DZS_Finish_Geo_Lod.py Script Start
        num_of_components = bpy.context.scene.dz_number_of_components
        original = bpy.context.active_object
        bpy.ops.object.select_all(action='DESELECT')
        for i in range(0, num_of_components):
            Geo = bpy.context.scene.objects["Geo " + str(i)]             
            bpy.context.scene.objects[Geo.name].select_set(True) 
        bpy.context.view_layer.objects.active = bpy.data.objects['Geo 0']
        Geo = bpy.data.objects['Geo 0']
        Geo.name = "Geometry"
        bpy.ops.object.join()
        bpy.ops.armatoolbox.create_components()
        bpy.ops.object.editmode_toggle()
        mesh = bmesh.from_edit_mesh(Geo.data)
        for v in mesh.verts:
            v.select = True
        mass = 1.0
        ArmaTools.distributeVertexMass(Geo, mass)
        bpy.ops.object.editmode_toggle()
        pass # DZS_Finish_Geo_Lod.py Script End
        if bpy.context.scene.dz_create_fire_geo == True:
            pass # DZS_Create_Fire_Geo.py Script Start
            bpy.ops.object.select_all(action='DESELECT')
            Object = bpy.context.scene.objects["Geometry"]
            bpy.context.view_layer.objects.active = Object
            Object.select_set(True)
            bpy.ops.object.duplicate(linked=False)
            active = bpy.context.active_object
            active.name = "Fire Geometry" 
            bpy.data.objects[active.name].armaObjProps.isArmaObject = True
            bpy.data.objects[active.name].armaObjProps.lod = '7.000e+15'
            pass # DZS_Create_Fire_Geo.py Script End
        else:
            pass
        if bpy.context.scene.dz_create_view_geo == True:
            pass # DZS_Create_View_Geo.py Script Start
            bpy.ops.object.select_all(action='DESELECT')
            mem = bpy.context.scene.objects["Geometry"]
            bpy.ops.mesh.primitive_cube_add()
            active = bpy.context.active_object
            active.name = "View Geometry"
            active.dimensions = mem.dimensions
            active.location = mem.location
            active.rotation_euler = mem.rotation_euler
            bpy.data.objects[active.name].armaObjProps.isArmaObject = True
            bpy.data.objects[active.name].armaObjProps.lod = '6.000e+15'
            bpy.ops.armatoolbox.create_components()
            if bpy.context.scene.dz_object_subtype == 'Pistol':
                bpy.ops.object.select_all(action='DESELECT')
                Object = bpy.context.scene.objects["View Geometry"]
                bpy.context.view_layer.objects.active = Object
                Object.select_set(True)
                bpy.ops.armatoolbox.add_prop()
                bpy.data.objects[Object.name].armaObjProps.namedProps[0].name = 'mass'
                bpy.data.objects[Object.name].armaObjProps.namedProps[0].value = '2.0'
            pass # DZS_Create_View_Geo.py Script End
        else:
            pass
        pass # DZS_Finalize_Geo.py Script Start
        bpy.ops.object.select_all(action='DESELECT')
        Object = bpy.context.scene.objects["Geometry"]
        bpy.context.view_layer.objects.active = Object
        Object.select_set(True)
        bpy.ops.armatoolbox.add_prop()
        bpy.data.objects[Object.name].armaObjProps.namedProps[0].name = 'autocenter'
        bpy.data.objects[Object.name].armaObjProps.namedProps[0].value = '0'
        pass # DZS_Finalize_Geo.py Script End
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Finish_Geo_Lod")

def dzf_material_to_path():
    try:
        pass # DZS_Material_To_Path.py Script Start
        import bpy
        import ArmaTools
        mat = bpy.context.active_object.active_material.name
        bpy.data.materials[mat].armaMatProps.texture = str(bpy.context.scene.dz_path + "data\\" + mat + "_co.tga")
        bpy.data.materials[mat].armaMatProps.rvMat = str(bpy.context.scene.dz_path + "data\\" + mat + ".rvmat")
        pass # DZS_Material_To_Path.py Script End
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Material_To_Path")

def dzf_finish_mem_lod():
    try:
        pass # DZS_Finish_Mem_Lod.py Script Start
        from mathutils import Vector
        obj_list = functions["dz_mem_points"]
        for i in obj_list:
            bpy.ops.object.select_all(action='DESELECT')
            lod = bpy.context.scene.objects[i]
            if lod:
                print("lod is " + str(lod))
                if lod.name != 'invview':
                    bpy.context.view_layer.objects.active = lod
                    lod.select_set(True)
                    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                    bpy.ops.object.select_all(action='DESELECT')
                    mem = bpy.context.scene.objects["Memory"]
                    bpy.ops.object.select_all(action='DESELECT')
                    bpy.context.scene.objects[lod.name].select_set(True)
                    bpy.context.scene.objects[mem.name].select_set(True)
                    bpy.context.view_layer.objects.active = bpy.data.objects[mem.name]
                    bpy.ops.object.join()        
                elif lod.name == 'invview':  
                    bpy.ops.object.select_all(action='DESELECT')
                    camera = bpy.context.active_object
                    bpy.ops.view3d.snap_cursor_to_active()
                    lod = bpy.context.scene.objects["invview"]
                    bpy.context.view_layer.objects.active = lod
                    lod.select_set(True)
                    bpy.ops.view3d.snap_selected_to_cursor()
                    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                    bpy.ops.object.select_all(action='DESELECT')
                    camera_to_delete = bpy.context.scene.objects["invview camera"]
                    bpy.context.view_layer.objects.active = camera_to_delete
                    camera_to_delete.select_set(True)
                    bpy.ops.object.delete()
                    mem = bpy.context.scene.objects["Memory"]
                    bpy.ops.object.select_all(action='DESELECT')
                    bpy.context.scene.objects[lod.name].select_set(True)
                    bpy.context.scene.objects[mem.name].select_set(True)
                    bpy.context.view_layer.objects.active = bpy.data.objects[mem.name]
                    bpy.ops.object.join()
                    bpy.ops.view3d.snap_cursor_to_center()        
        pass # DZS_Finish_Mem_Lod.py Script End
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Finish_Mem_Lod")

def dzf_create_geo_lod():
    try:
        pass # DZS_Create_Geo_Lod.py Script Start
        num_of_components = bpy.context.scene.dz_number_of_components
        bpy.ops.object.select_all(action='DESELECT')
        if bpy.context.scene.dz_object_subtype == 'Inventory Base':
            mem = bpy.context.scene.objects["0"]
        if bpy.context.scene.dz_object_subtype == 'Melee Weapon':
            mem = bpy.context.scene.objects["View Pilot"]
        if bpy.context.scene.dz_object_subtype == 'Pistol':
            mem = bpy.context.scene.objects["0"]
        for i in range(0, num_of_components):               
            bpy.ops.mesh.primitive_cube_add()
            active = bpy.context.active_object
            active.name = "Geo " + str(i) 
            #copy transforms
            active.dimensions = mem.dimensions
            active.location = mem.location
            active.rotation_euler = mem.rotation_euler
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True, properties=True)
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS')
            bpy.data.objects[active.name].armaObjProps.isArmaObject = True
            bpy.data.objects[active.name].armaObjProps.lod = '1.000e+13'
        pass # DZS_Create_Geo_Lod.py Script End
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Create_Geo_Lod")

def dzf_create_script():
    try:
        pass # DZS_Create_Script.py Script Start
        import bpy
        name = bpy.context.scene.dz_object_name
        filename = name + ".c"
        if filename not in bpy.data.texts:
            bpy.data.texts.new(filename)
            area = next(area for area in bpy.context.screen.areas if area.type == 'TEXT_EDITOR')
            area.spaces.active.text = bpy.data.texts[filename]


            bpy.data.texts[filename].write("class ###NAME### extends " + bpy.context.scene.dz_type_of_object + "{};")
            for line in bpy.data.texts[filename].lines:
                if '###NAME###' in line.body:
                    line.body = line.body.replace('###NAME###', name)
        pass # DZS_Create_Script.py Script End
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Create_Script")

def dzf_create_dayz_material():
    try:
        if bpy.context.scene.dz_material:
            pass
        else:
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__),'assets','DayZ.blend') + r"\Material", filename=r"DayZ Material", link=False)
            try: exec(r"bpy.data.materials['DayZ Material'].use_fake_user = True")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.data.materials['DayZ Material'].use_fake_user = True")
            bpy.context.scene.dz_material = True
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Create_DayZ_Material")

def dzf_convert_to_dayz_material():
    try:
        pass # DZS_Convert_Material.py Script Start
        import bpy
        from pathlib import Path

        def replace_material(object,old_material,new_material):
            """
            replace a material in blender.
            params:
                object - object for which we are replacing the material
                old_material - The old material name as a string
                new_material - The new material name as a string
            """
            ob = object
            om = bpy.data.materials[old_material]
            om_texture = om.armaMatProps.texture
            om_rvMat = om.armaMatProps.rvMat
            txt_0 =  om_texture.split('data\\')
            txt_image = txt_0[1]
            txt_1 = txt_image.split('_')
            txt_name = txt_1[0]
            txt_2 = txt_1[1].split('.')
            txt_pre = txt_2[0]
            txt_ext = "." + txt_2[1]
            nnm_name = txt_name
            nnm_mat_name = nnm_name + ".rvmat"
            print(nnm_name)
            textures_list = [txt_pre,"nohq","dt","mc","as","smdi"]
            for t in textures_list:
                filename = Path('P:\\' + bpy.context.scene.dz_path + "\\data\\" + txt_name + "_" + t + ".tga")
                if not filename.exists():
                    print("Oops, file doesn't exist!")
                else:
                    bpy.data.images.load('P:\\' + bpy.context.scene.dz_path + "\\data\\" + txt_name + "_" + t + ".tga", check_existing=True)
            nm = bpy.data.materials[new_material]
            # Iterate over the material slots and replace the material
            for s in ob.material_slots:
                if s.material.name == old_material:
                    nnm = nm.copy()
                    nnm.name = nnm_mat_name
                    nnm.armaMatProps.texture = om_texture
                    nnm.armaMatProps.rvMat = om_rvMat
                    s.material = nnm
            for n in nnm.node_tree.nodes:
                bpy.context.object.active_material = nnm
                if "CO" in n.name:
                    print("CO is in " + n.name)
                    tex = bpy.data.images.get(txt_name + "_co.tga")
                    n.image = tex
                if "SMDI" in n.name:
                    print("CO is in " + n.name)
                    tex = bpy.data.images.get(txt_name + "_smdi.tga")
                    n.image = tex
                if "NOHQ" in n.name:
                    print("CO is in " + n.name)
                    tex = bpy.data.images.get(txt_name + "_nohq.tga")
                    n.image = tex
                if "AS" in n.name:
                    print("CO is in " + n.name)
                    tex = bpy.data.images.get(txt_name + "_as.tga")
                    n.image = tex
        obj = bpy.context.object
        for mat in obj.data.materials:
            #print(mat.armaMatProps.texture)
        # print(mat.armaMatProps.rvMat)
            replace_material(obj,mat.name,"DayZ Material")
            mat.user_clear()
            bpy.data.materials.remove(mat)
        pass # DZS_Convert_Material.py Script End
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Convert_To_DayZ_Material")

def dzf_create_dayz_config():
    try:
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__),'assets','DayZ.blend') + r"\Text", filename=bpy.context.scene.dz_type_of_object, link=False)
        try: exec(r"bpy.data.texts[bpy.context.scene.dz_type_of_object].name = 'config.cpp'")
        except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.data.texts[bpy.context.scene.dz_type_of_object].name = 'config.cpp'")
        pass # DZS_Create_DayZ_Config.py Script Start
        name = bpy.context.scene.dz_object_name
        path = bpy.context.scene.dz_path
        matst = functions["dz_list_of_materials"][0].name
        material = matst.replace(".rvmat","")
        for line in bpy.data.texts['config.cpp'].lines:
            if '###MOD###' in line.body:
                line.body = line.body.replace('###MOD###', bpy.context.scene.dz_mod)
            if '###NAME###' in line.body:
                line.body = line.body.replace('###NAME###', name)
            if '###PATH###' in line.body:
                line.body = line.body.replace('###PATH###', "\\" + path)
            if '###RVMAT###' in line.body:
                line.body = line.body.replace('###RVMAT###', path + "data\\" + material + ".rvmat")
            if '###RVMATDAMAGE###' in line.body:
                line.body = line.body.replace('###RVMATDAMAGE###', path + "data\\" + material + "_damage" + ".rvmat")
            if '###RVMATDESTRUCT###' in line.body:
                line.body = line.body.replace('###RVMATDESTRUCT###', path + "data\\" + material + "_destruct" + ".rvmat")
        pass # DZS_Create_DayZ_Config.py Script End
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Create_DayZ_Config")

def dzf_create_dayz_object():
    try:
        pass # DZS_Create_DayZ_Object.py Script Start
        import os
        obj_list = ['pelvis', 'launcher', 'weapon', 'propweaponbody', 'propweaponslide', 'propweaponmag', 'propweapon01', 'propweapon02', 'propweapon03', 'propweapon04', 'propweapon05', 'propweapon06', 'propweapon07', 'propweapon08', 'propweapon09', 'propweapon10', 'lefthipextra', 'righthipextra', 'propbeltleft', 'propbeltright', 'propbeltcenter', 'turningaxis', 'propbackpackmain', 'propbackpacktop', 'propbackpackextra', 'propbackpackleft', 'propbackpackright', 'spine', 'spine1', 'proprifleunderarm', 'spine2', 'proprifleback', 'propvestleft', 'propvestright', 'propvestfront', 'propvestlower', 'spine3', 'propvestupper', 'propvestback', 'neck', 'neck1', 'head', 'prophelmet', 'prophelmetvisor', 'propmouth', 'propmask', 'propglasses', 'prophelmetchin', 'propcamera1st', 'headcutscene', 'eyeleft', 'eyeright', 'face_browfrontleft', 'face_browfrontright', 'face_browmiddle', 'face_browsideleft', 'face_browsideright', 'face_cornerleft', 'face_cornerright', 'face_eyelidlowerleft', 'face_eyelidlowerright', 'face_eyelids', 'face_eyelidupperleft', 'face_eyelidupperright', 'face_forehead', 'face_cheekfrontleft', 'face_cheekfrontright', 'face_cheeksideleft', 'face_cheeksideright', 'face_cheekupperleft', 'face_cheekupperright', 'face_chin', 'face_chopleft', 'face_chopright', 'face_jawbone', 'face_jowl', 'face_liplowerleft', 'face_liplowermiddle', 'face_liplowerright', 'face_lipupperleft', 'face_lipuppermiddle', 'face_lipupperright', 'face_nostrilleft', 'face_nostrilright', 'face_tongue', 'beard', 'hair', 'leftshoulder', 'leftarm', 'leftarmextra', 'leftarmroll', 'leftelbowextra', 'leftforearm', 'leftforearmextra', 'leftforearmroll', 'leftwristextra', 'lefthand', 'prophandl', 'lefthandring', 'lefthandring1', 'lefthandring2', 'lefthandring3', 'lefthandpinky1', 'lefthandpinky2', 'lefthandpinky3', 'lefthandmiddle1', 'lefthandmiddle2', 'lefthandmiddle3', 'lefthandindex1', 'lefthandindex2', 'lefthandindex3', 'lefthandthumb1', 'lefthandthumb2', 'lefthandthumb3', 'rightshoulder', 'rightarm', 'rightarmextra', 'rightarmroll', 'rightelbowextra', 'rightforearm', 'rightforearmextra', 'rightforearmroll', 'rightwristextra', 'righthand', 'prophandr', 'righthandring', 'righthandring1', 'righthandring2', 'righthandring3', 'righthandpinky1', 'righthandpinky2', 'righthandpinky3', 'righthandmiddle1', 'righthandmiddle2', 'righthandmiddle3', 'righthandindex1', 'righthandindex2', 'righthandindex3', 'righthandthumb1', 'righthandthumb2', 'righthandthumb3', 'leftupleg', 'leftuplegroll', 'propthighleft', 'leftkneeextra', 'leftleg', 'leftlegroll', 'leftfoot', 'lefttoebase', 'rightupleg', 'rightuplegroll', 'propthighright', 'rightkneeextra', 'rightleg', 'rightlegroll', 'rightfoot', 'righttoebase', 'camera', 'righthand_dummy']
        if bpy.context.scene.dz_type_of_object == 'Inventory_Base':
            bpy.context.scene.dz_object_subtype = 'Inventory Base'
            functions["dz_cfg_name"] = 'normalCFG'
        if bpy.context.scene.dz_type_of_object == 'BaseballBat':
            bpy.context.scene.dz_object_subtype = 'Melee Weapon' 
            functions["dz_cfg_name"] = 'normalCFG'
        if bpy.context.scene.dz_type_of_object == 'Colt1911_Base':
            bpy.context.scene.dz_object_subtype = 'Pistol'
            functions["dz_cfg_name"] = 'Pistol'
        if bpy.context.scene.dz_type_of_object == 'CZ75_Base':
            bpy.context.scene.dz_object_subtype = 'Pistol'
            functions["dz_cfg_name"] = 'Pistol'
        functions["dz_list_of_hidden_selections"].clear()
        functions["dz_list_of_materials"].clear()
        if bpy.context.scene.dz_object_subtype == 'Inventory Base':
            original = bpy.context.active_object
            bpy.ops.object.duplicate(linked=False)
            active = bpy.context.active_object
            active.name = "0"
            active.select_set(True)
            bpy.data.objects[active.name].armaObjProps.isArmaObject = True
            bpy.data.objects[active.name].armaObjProps.lod = '-1.0'
            bpy.data.objects[active.name].armaObjProps.lodDistance = 0.00
            bpy.ops.object.select_all(action='INVERT')
            bpy.ops.object.delete()
            bpy.ops.object.select_all(action='SELECT')
        if bpy.context.scene.dz_object_subtype == 'Melee Weapon':
            original = bpy.context.active_object
            bpy.ops.object.duplicate(linked=False)
            active = bpy.context.active_object
            active.name = "View Pilot"
            active.select_set(True)
            bpy.data.objects[active.name].armaObjProps.isArmaObject = True
            bpy.data.objects[active.name].armaObjProps.lod = '1.100e+3'
            bpy.ops.object.select_all(action='INVERT')
            bpy.ops.object.delete()
            bpy.ops.object.select_all(action='SELECT')
        if bpy.context.scene.dz_object_subtype == 'Pistol':
            file_path = bpy.context.scene.dz_asset_path
            inner_path = 'Object'
            object_name = bpy.context.scene.dz_type_of_object + '_Main'
            bpy.ops.wm.append(
                filepath=os.path.join(file_path, inner_path, object_name),
                directory=os.path.join(file_path, inner_path),
                filename=object_name
                )
            active = bpy.context.active_object
            active.name = "0"
            active = bpy.context.scene.objects[object_name]
            active.name = "Pistol Refrence"
            bpy.ops.object.select_all(action='DESELECT')
        for i in active.vertex_groups:
            if i.name not in obj_list:
                functions["dz_list_of_hidden_selections"].append(i.name)    
        for mat in active.material_slots:
            functions["dz_list_of_materials"].append(mat)
        pass # DZS_Create_DayZ_Object.py Script End
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Create_DayZ_Object")

def dzf_reset_tools():
    try:
        pass # DZS_Reset_Tools.py Script Start
        dayz_modding_tools["show_obj_type"] = True;
        dayz_modding_tools["show_create_obj"] = False;
        dayz_modding_tools["show_create_mem_lod"] = False;
        dayz_modding_tools["show_create_mem_points"] = False;
        dayz_modding_tools["show_create_geo_lod"] = False;
        dayz_modding_tools["show_button_combine_geo"] = False;
        dayz_modding_tools["show_finalize"] = False;
        bpy.context.scene.dz_create_view_geo = True;
        bpy.context.scene.dz_material = False;
        pass # DZS_Reset_Tools.py Script End
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Reset_Tools")

def update_dz_path(self, context):
    if functions["dz_p"] in sn_cast_string(self.dz_path):
        sn_cast_blend_data(self).dz_path = sn_cast_string(self.dz_path).replace(functions["dz_p"], r"")
    else:
        pass
    if functions["pz_quotes"] in sn_cast_string(self.dz_path):
        sn_cast_blend_data(self).dz_path = sn_cast_string(self.dz_path).replace(functions["pz_quotes"], r"")
    else:
        pass
    if functions["dz_data"] in sn_cast_string(self.dz_path):
        sn_cast_blend_data(self).dz_path = (sn_cast_string(sn_cast_string(self.dz_path).split(functions["dz_data"])[0]) + functions["dz_slash"])
    else:
        pass

def dzf_confirm_object_type():
    try:
        try: exec(r"dayz_modding_tools['show_obj_type'] = False")
        except Exception as exc: sn_handle_script_line_exception(exc, r"dayz_modding_tools['show_obj_type'] = False")
        try: exec(r"dayz_modding_tools['show_create_obj'] = True")
        except Exception as exc: sn_handle_script_line_exception(exc, r"dayz_modding_tools['show_create_obj'] = True")
        bpy.context.scene.dz_asset_path = os.path.join(os.path.dirname(__file__),'assets','DayZ.blend')
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Confirm_Object_Type")

def dzf_create_memory_lod():
    try:
        function_return_8EF42 = dzf_deselect()
        if bpy.context.scene.dz_object_subtype == r"Inventory Base":
            function_return_C493A = dzf_select(r"0", )
            pass # DZS_Create_Memory_Lod.py Script Start
            bpy.ops.object.duplicate(linked=False)
            active = bpy.context.active_object
            active.name = "Memory"
            active.modifiers.clear()
            bpy.data.objects[active.name].armaObjProps.isArmaObject = True
            bpy.data.objects[active.name].armaObjProps.lod = '1.000e+15'
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
            #create a cube for the bounding box
            bpy.ops.mesh.primitive_cube_add() 
            #our new cube is now the active object, so we can keep track of it in a variable:
            bound_box = bpy.context.active_object 
            #copy transforms
            bound_box.dimensions = active.dimensions
            bound_box.location = active.location
            bound_box.rotation_euler = active.rotation_euler
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True, properties=True)
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS')
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.view_layer.objects.active = bpy.data.objects[active.name]
            bpy.ops.object.editmode_toggle()
            mesh = bmesh.from_edit_mesh(active.data)
            for v in mesh.verts:
                v.select = True
            bpy.ops.mesh.delete(type='VERT')
            bpy.ops.object.editmode_toggle()
            bpy.context.scene.objects[bound_box.name].select_set(True)
            bpy.context.scene.objects[active.name].select_set(True)
            bpy.context.view_layer.objects.active = bpy.data.objects[active.name]
            bpy.ops.object.join()
            box_verts = [vert.co for vert in active.data.vertices]
            boundingbox_max = bpy.context.active_object.vertex_groups.new(name='boundingbox_max')
            bb_max = [1]
            boundingbox_max.add(bb_max, 1.0, 'ADD')
            boundingbox_min = bpy.context.active_object.vertex_groups.new(name='boundingbox_min')
            bb_min = [6]
            boundingbox_min.add(bb_min, 1.0, 'ADD')
            pass # DZS_Create_Memory_Lod.py Script End
            function_return_BD362 = dzf_skip(r"show_create_mem_lod", r"show_create_mem_points", )
        else:
            pass
        if bpy.context.scene.dz_object_subtype == r"Melee Weapon":
            function_return_D077D = dzf_select(r"View Pilot", )
            pass # DZS_Create_Memory_Lod.py Script Start
            bpy.ops.object.duplicate(linked=False)
            active = bpy.context.active_object
            active.name = "Memory"
            active.modifiers.clear()
            bpy.data.objects[active.name].armaObjProps.isArmaObject = True
            bpy.data.objects[active.name].armaObjProps.lod = '1.000e+15'
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
            #create a cube for the bounding box
            bpy.ops.mesh.primitive_cube_add() 
            #our new cube is now the active object, so we can keep track of it in a variable:
            bound_box = bpy.context.active_object 
            #copy transforms
            bound_box.dimensions = active.dimensions
            bound_box.location = active.location
            bound_box.rotation_euler = active.rotation_euler
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True, properties=True)
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS')
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.view_layer.objects.active = bpy.data.objects[active.name]
            bpy.ops.object.editmode_toggle()
            mesh = bmesh.from_edit_mesh(active.data)
            for v in mesh.verts:
                v.select = True
            bpy.ops.mesh.delete(type='VERT')
            bpy.ops.object.editmode_toggle()
            bpy.context.scene.objects[bound_box.name].select_set(True)
            bpy.context.scene.objects[active.name].select_set(True)
            bpy.context.view_layer.objects.active = bpy.data.objects[active.name]
            bpy.ops.object.join()
            box_verts = [vert.co for vert in active.data.vertices]
            boundingbox_max = bpy.context.active_object.vertex_groups.new(name='boundingbox_max')
            bb_max = [1]
            boundingbox_max.add(bb_max, 1.0, 'ADD')
            boundingbox_min = bpy.context.active_object.vertex_groups.new(name='boundingbox_min')
            bb_min = [6]
            boundingbox_min.add(bb_min, 1.0, 'ADD')
            pass # DZS_Create_Memory_Lod.py Script End
            function_return_EE992 = dzf_skip(r"show_create_mem_lod", r"show_create_mem_points", )
        else:
            pass
        if bpy.context.scene.dz_object_subtype == r"Pistol":
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__),'assets','DayZ.blend') + r"\Object", filename=(bpy.context.scene.dz_type_of_object + r"_Memory"), link=False)
            setattr(bpy.data.objects[(bpy.context.scene.dz_type_of_object + r"_Memory")],r"name",r"Memory")
            function_return_2E55D = dzf_skip(r"show_create_mem_lod", r"show_create_mem_points", )
        else:
            pass
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Create_Memory_LOD")

def dzf_done():
    try:
        print((bpy.context.scene.dz_drive + bpy.context.scene.dz_path + bpy.context.scene.dz_object_name))
        bpy.ops.armatoolbox.export_p3d('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',filepath=(bpy.context.scene.dz_drive + bpy.context.scene.dz_path + bpy.context.scene.dz_object_name),check_existing=True,filter_glob=r"*.p3d",selectionOnly=False,applyModifiers=True,mergeSameLOD=True,)
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Done")

def dzf_create_model_cfg():
    try:
        if functions["dz_cfg_name"] == r"normalCFG":
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__),'assets','DayZ.blend') + r"\Text", filename=r"normalCFG", link=False)
            try: exec(r"bpy.data.texts['normalCFG'].name = 'model.cfg'")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.data.texts['normalCFG'].name = 'model.cfg'")
            pass # DZS_Create_Model_CFG.py Script Start
            bpy.ops.object.select_all(action='DESELECT')
            name = bpy.context.scene.dz_object_name
            sections = ""
            count = 0
            obj_list = ['pelvis', 'launcher', 'weapon', 'propweaponbody', 'propweaponslide', 'propweaponmag', 'propweapon01', 'propweapon02', 'propweapon03', 'propweapon04', 'propweapon05', 'propweapon06', 'propweapon07', 'propweapon08', 'propweapon09', 'propweapon10', 'lefthipextra', 'righthipextra', 'propbeltleft', 'propbeltright', 'propbeltcenter', 'turningaxis', 'propbackpackmain', 'propbackpacktop', 'propbackpackextra', 'propbackpackleft', 'propbackpackright', 'spine', 'spine1', 'proprifleunderarm', 'spine2', 'proprifleback', 'propvestleft', 'propvestright', 'propvestfront', 'propvestlower', 'spine3', 'propvestupper', 'propvestback', 'neck', 'neck1', 'head', 'prophelmet', 'prophelmetvisor', 'propmouth', 'propmask', 'propglasses', 'prophelmetchin', 'propcamera1st', 'headcutscene', 'eyeleft', 'eyeright', 'face_browfrontleft', 'face_browfrontright', 'face_browmiddle', 'face_browsideleft', 'face_browsideright', 'face_cornerleft', 'face_cornerright', 'face_eyelidlowerleft', 'face_eyelidlowerright', 'face_eyelids', 'face_eyelidupperleft', 'face_eyelidupperright', 'face_forehead', 'face_cheekfrontleft', 'face_cheekfrontright', 'face_cheeksideleft', 'face_cheeksideright', 'face_cheekupperleft', 'face_cheekupperright', 'face_chin', 'face_chopleft', 'face_chopright', 'face_jawbone', 'face_jowl', 'face_liplowerleft', 'face_liplowermiddle', 'face_liplowerright', 'face_lipupperleft', 'face_lipuppermiddle', 'face_lipupperright', 'face_nostrilleft', 'face_nostrilright', 'face_tongue', 'beard', 'hair', 'leftshoulder', 'leftarm', 'leftarmextra', 'leftarmroll', 'leftelbowextra', 'leftforearm', 'leftforearmextra', 'leftforearmroll', 'leftwristextra', 'lefthand', 'prophandl', 'lefthandring', 'lefthandring1', 'lefthandring2', 'lefthandring3', 'lefthandpinky1', 'lefthandpinky2', 'lefthandpinky3', 'lefthandmiddle1', 'lefthandmiddle2', 'lefthandmiddle3', 'lefthandindex1', 'lefthandindex2', 'lefthandindex3', 'lefthandthumb1', 'lefthandthumb2', 'lefthandthumb3', 'rightshoulder', 'rightarm', 'rightarmextra', 'rightarmroll', 'rightelbowextra', 'rightforearm', 'rightforearmextra', 'rightforearmroll', 'rightwristextra', 'righthand', 'prophandr', 'righthandring', 'righthandring1', 'righthandring2', 'righthandring3', 'righthandpinky1', 'righthandpinky2', 'righthandpinky3', 'righthandmiddle1', 'righthandmiddle2', 'righthandmiddle3', 'righthandindex1', 'righthandindex2', 'righthandindex3', 'righthandthumb1', 'righthandthumb2', 'righthandthumb3', 'leftupleg', 'leftuplegroll', 'propthighleft', 'leftkneeextra', 'leftleg', 'leftlegroll', 'leftfoot', 'lefttoebase', 'rightupleg', 'rightuplegroll', 'propthighright', 'rightkneeextra', 'rightleg', 'rightlegroll', 'rightfoot', 'righttoebase', 'camera', 'righthand_dummy']
            Tabs = "\t\t\t"
            list = functions["dz_list_of_hidden_selections"]
            filename = "model.cfg"
            if filename in bpy.data.texts:
                for i in list:
                    if i not in obj_list: 
                        count += 1
                for i in list:
                    if i not in obj_list:
                        if count > 1:
                            sections += Tabs + "\"" + i.name + "\"," + '\n'
                            bpy.data.texts[filename].write(Tabs + "\"" + i + "\"," + '\n')
                        if count == 1:
                            bpy.data.texts[filename].write(Tabs + "\"" + i + "\"")
                            sections += Tabs + "\"" + i + "\""
                        count -= 1
                bpy.data.texts[filename].write("\n")
                bpy.data.texts[filename].write("\t\t};\n")
                bpy.data.texts[filename].write("\t};\n")
                bpy.data.texts[filename].write("};\n")
                for line in bpy.data.texts['model.cfg'].lines:
                    if '###NAME###' in line.body:
                        line.body = line.body.replace('###NAME###', name)
            pass # DZS_Create_Model_CFG.py Script End
        else:
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__),'assets','DayZ.blend') + r"\Text", filename=(functions["dz_cfg_name"] + r"CFG"), link=False)
            try: exec(r"bpy.data.texts[functions['dz_cfg_name'] + 'CFG'].name = 'model.cfg'")
            except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.data.texts[functions['dz_cfg_name'] + 'CFG'].name = 'model.cfg'")
            for_node_7C3BF = 0
            for_node_index_7C3BF = 0
            for for_node_index_7C3BF, for_node_7C3BF in enumerate(sn_cast_list(getattr(bpy.data.texts[r"model.cfg"],r"lines"))):
                if r"###NAME###" in sn_cast_string(getattr(sn_cast_blend_data(for_node_7C3BF),r"body")):
                    setattr(sn_cast_blend_data(for_node_7C3BF),r"body",sn_cast_string(getattr(sn_cast_blend_data(for_node_7C3BF),r"body")).replace(r"###NAME###", bpy.context.scene.dz_object_name))
                else:
                    pass
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Create_Model_CFG")

def dzf_create_lods():
    try:
        pass # DZS_Create_Lods.py Script Start
        num_of_lods = bpy.context.scene.dz_number_of_lods
        obj_list = []
        original = bpy.context.active_object
        bpy.ops.object.select_all(action='DESELECT')
        #bpy.data.texts[bpy.context.scene.dz_type_of_object + 'CFG'].name = 'Memory'
        if bpy.context.scene.dz_object_subtype == 'Inventory Base':
            Object = bpy.context.scene.objects["0"]
            bpy.context.view_layer.objects.active = Object
            Object.select_set(True)   
            for i in range(1, num_of_lods + 1):               
                bpy.ops.object.duplicate(linked=False)
                active = bpy.context.active_object
                active.name = str(i)
                bpy.data.objects[active.name].armaObjProps.isArmaObject = True
                bpy.data.objects[active.name].armaObjProps.lod = '-1.0'
                bpy.data.objects[active.name].armaObjProps.lodDistance = float(i)
                obj_list.append(active)
            index = 5
            for i in obj_list:
                    Obj = i.modifiers.new("Decimate",'DECIMATE')
                    Obj.decimate_type = "DISSOLVE"
                    Obj.angle_limit = radians(index)
                    index = index + 5
        if bpy.context.scene.dz_object_subtype == 'Melee Weapon':
            Object = bpy.context.scene.objects["View Pilot"]
            bpy.context.view_layer.objects.active = Object
            Object.select_set(True)   
            for i in range(2, num_of_lods + 2):      
                bpy.ops.object.duplicate(linked=False)
                active = bpy.context.active_object
                active.name = str(i)
                bpy.data.objects[active.name].armaObjProps.isArmaObject = True
                bpy.data.objects[active.name].armaObjProps.lod = '-1.0'
                bpy.data.objects[active.name].armaObjProps.lodDistance = float(i)
                obj_list.append(active)
            index = 5
            for i in obj_list:
                    Obj = i.modifiers.new("Decimate",'DECIMATE')
                    Obj.decimate_type = "DISSOLVE"
                    Obj.angle_limit = radians(index)
                    index = index + 5
        if bpy.context.scene.dz_object_subtype == 'Pistol':
            Object = bpy.context.scene.objects["0"]
            bpy.context.view_layer.objects.active = Object
            Object.select_set(True)   
            for i in range(1, num_of_lods + 1):               
                bpy.ops.object.duplicate(linked=False)
                active = bpy.context.active_object
                active.name = str(i)
                bpy.data.objects[active.name].armaObjProps.isArmaObject = True
                bpy.data.objects[active.name].armaObjProps.lod = '-1.0'
                bpy.data.objects[active.name].armaObjProps.lodDistance = float(i)
                obj_list.append(active)
            index = 5
            for i in obj_list:
                    Obj = i.modifiers.new("Decimate",'DECIMATE')
                    Obj.decimate_type = "DISSOLVE"
                    Obj.angle_limit = radians(index)
                    index = index + 5
        pass # DZS_Create_Lods.py Script End
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Create_Lods")

def dzf_convert_paa():
    try:
        pass # DZS_PAA_To_TGA.py Script Start
        import bpy
        import os
        Tools = bpy.context.preferences.addons['dayz_modding_tools'].preferences.dayz_tools_directory
        if Tools == "":
            return
        PAAtoTGA = open('P:\\' + bpy.context.scene.dz_path + "\\data\\" + 'PAAtoTGA.bat','w')
        Batch = 'for %%f in (*.paa) do (' + "\"" +  Tools + "Bin\\" + 'ImageToPAA\ImageToPAA.exe' + "\" " +'"%%~nf.paa" "%%~nf.tga" )'
        PAAtoTGA.write(Batch)
        PAAtoTGA.close()
        print('P:\\' + bpy.context.scene.dz_path + "data\\" + 'PAAtoTGA.bat')
        os.chdir('P:\\' + bpy.context.scene.dz_path + "data\\")
        os.system("PAAtoTGA.bat")
        os.remove("PAAtoTGA.bat")
        pass # DZS_PAA_To_TGA.py Script End
    except Exception as exc:
        print(str(exc) + " | Error in function DZF_Convert_PAA")


#######   Operators
def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc


###############   EVALUATED CODE
#######   DayZ Modding Tools
class SNA_PT_Memory_Lod_19419(bpy.types.Panel):
    bl_label = "Memory Lod"
    bl_idname = "SNA_PT_Memory_Lod_19419"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return dayz_modding_tools["show_create_mem_lod"]

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Memory Lod panel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            op = col.operator("sna.dz_create_memory_lod_op",text=r"Create",emboss=True,depress=False,icon_value=0)
            op = col.operator("sna.dz_skip_mem_lod_op",text=r"Skip",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Memory Lod panel")


class SNA_PT_Geo_Lods_ADAC9(bpy.types.Panel):
    bl_label = "Geo Lods"
    bl_idname = "SNA_PT_Geo_Lods_ADAC9"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return dayz_modding_tools["show_create_geo_lod"]

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Geo Lods panel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=True)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            row = col.row(align=False)
            row.enabled = not dayz_modding_tools["show_button_combine_geo"]
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'dz_number_of_components',text=r"Components",emboss=True,slider=True,)
            op = row.operator("sna.dz_create_geo_lod_op",text=r"Create",emboss=True,depress=False,icon_value=0)
            row = col.row(align=False)
            row.enabled = dayz_modding_tools["show_button_combine_geo"]
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'dz_create_fire_geo',icon_value=0,text=r"Fire Geo",emboss=True,toggle=False,invert_checkbox=False,)
            row.prop(bpy.context.scene,'dz_create_view_geo',icon_value=0,text=r"View Geo",emboss=True,toggle=False,invert_checkbox=False,)
            row = col.row(align=False)
            row.enabled = dayz_modding_tools["show_button_combine_geo"]
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.dz_finish_geo_lod_op",text=r"Done",emboss=True,depress=False,icon_value=0)
            op = col.operator("sna.dz_skip_geo_lod_op",text=r"Skip",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Geo Lods panel")


class SNA_PT_DayZ_Object_Type_17CBC(bpy.types.Panel):
    bl_label = "DayZ Object Type"
    bl_idname = "SNA_PT_DayZ_Object_Type_17CBC"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return dayz_modding_tools["show_obj_type"]

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in DayZ Object Type panel header")

    def draw(self, context):
        try:
            layout = self.layout
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            box.prop(bpy.context.scene,'dz_type_of_object',icon_value=0,text=r"Type",emboss=True,expand=False,)
            box.prop(bpy.context.scene,'dz_object_name',icon_value=0,text=r"DZ_Object_Name",emboss=True,)
            col = layout.column(align=False)
            col.enabled = bpy.context.scene.dz_object_name != r""
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            op = col.operator("sna.dz_confirm_object_type_op",text=r"Confirm",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in DayZ Object Type panel")


class SNA_PT_Create_DayZ_Object_351D7(bpy.types.Panel):
    bl_label = "Create DayZ Object"
    bl_idname = "SNA_PT_Create_DayZ_Object_351D7"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return dayz_modding_tools["show_create_obj"]

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Create DayZ Object panel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            col.prop(bpy.context.scene,'dz_number_of_lods',text=r"LODS",emboss=True,slider=False,)
            col = col.column(align=False)
            col.enabled = bpy.context.active_object.type=="MESH"
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            op = col.operator("sna.dz_create_dayz_object_op",text=r"Confirm",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Create DayZ Object panel")


class SNA_PT_DayZ_48213(bpy.types.Panel):
    bl_label = "DayZ"
    bl_idname = "SNA_PT_DayZ_48213"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return True

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in DayZ panel header")

    def draw(self, context):
        try:
            layout = self.layout
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            box.prop(bpy.context.scene,'dz_mod',icon_value=0,text=r"Mod Name",emboss=True,)
            box.prop(bpy.context.scene,'dz_path',icon_value=0,text=r"Directory",emboss=True,)
        except Exception as exc:
            print(str(exc) + " | Error in DayZ panel")


class SNA_PT_Finalize_7DC5D(bpy.types.Panel):
    bl_label = "Finalize"
    bl_idname = "SNA_PT_Finalize_7DC5D"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return dayz_modding_tools["show_finalize"]

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Finalize panel header")

    def draw(self, context):
        try:
            layout = self.layout
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            box.prop(bpy.context.scene,'dz_hidden_selections',icon_value=0,text=r"Create HIdden Selections?",emboss=True,toggle=False,invert_checkbox=False,)
            op = box.operator("sna.dz_create_model_cfg_op",text=r"Create Model CFG",emboss=True,depress=False,icon_value=0)
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            col = box.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            op = col.operator("sna.dz_create_dayz_config_op",text=r"Create Config",emboss=True,depress=False,icon_value=0)
            op = col.operator("sna.dz_create_script_op",text=r"Create Script",emboss=True,depress=False,icon_value=0)
            box = layout.box()
            box.enabled = True
            box.alert = False
            box.scale_x = 1.0
            box.scale_y = 1.0
            op = box.operator("sna.dz_done_op",text=r"Done",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Finalize panel")


class SNA_PT_Memory_Lod_9CBC5(bpy.types.Panel):
    bl_label = "Memory Lod"
    bl_idname = "SNA_PT_Memory_Lod_9CBC5"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return (dayz_modding_tools["show_create_mem_points"] and r"Pistol" == bpy.context.scene.dz_object_subtype)

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Memory Lod panel header")

    def draw(self, context):
        try:
            layout = self.layout
            op = layout.operator("sna.dz_finish_mem_lod_op",text=r"Done",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Memory Lod panel")


class SNA_PT_Memory_Lod_7A506(bpy.types.Panel):
    bl_label = "Memory Lod"
    bl_idname = "SNA_PT_Memory_Lod_7A506"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return (dayz_modding_tools["show_create_mem_points"] and r"Inventory Base" == bpy.context.scene.dz_object_subtype)

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Memory Lod panel header")

    def draw(self, context):
        try:
            layout = self.layout
            op = layout.operator("sna.dz_create_ce_center_op",text=r"Create ce_center",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.dz_create_ce_radius_op",text=r"Create ce_radius",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.dz_create_throwingimpulse_op",text=r"Create throwingimpulseposition",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.dz_create_invview_op",text=r"Create invview",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.dz_finish_mem_lod_op",text=r"Done",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Memory Lod panel")


class SNA_PT_Memory_Lod_87AB4(bpy.types.Panel):
    bl_label = "Memory Lod"
    bl_idname = "SNA_PT_Memory_Lod_87AB4"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return (dayz_modding_tools["show_create_mem_points"] and r"Melee Weapon" == bpy.context.scene.dz_object_subtype)

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Memory Lod panel header")

    def draw(self, context):
        try:
            layout = self.layout
            op = layout.operator("sna.dz_create_ce_center_op",text=r"Create ce_center",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.dz_create_ce_radius_op",text=r"Create ce_radius",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.dz_create_throwingimpulse_op",text=r"Create throwingimpulseposition",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.dz_create_meleerangestart_op",text=r"Create meleerangestart",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.dz_create_meleerangeend_op",text=r"Create meleerangeend",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sn.compile",text=r"Create invview",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.dz_skip_mem_points_op",text=r"Skip",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Memory Lod panel")
try: exec(r"from mathutils import Vector")
except Exception as exc: sn_handle_script_line_exception(exc, r"from mathutils import Vector")
try: exec(r"import bpy,bmesh")
except Exception as exc: sn_handle_script_line_exception(exc, r"import bpy,bmesh")
try: exec(r"from math import radians")
except Exception as exc: sn_handle_script_line_exception(exc, r"from math import radians")
try: exec(r"functions['dz_mem_points'].clear()")
except Exception as exc: sn_handle_script_line_exception(exc, r"functions['dz_mem_points'].clear()")
try: exec(r"import ArmaTools")
except Exception as exc: sn_handle_script_line_exception(exc, r"import ArmaTools")
try: exec(r"import subprocess")
except Exception as exc: sn_handle_script_line_exception(exc, r"import subprocess")

def sn_append_menu_4959B(self,context):
    try:
        layout = self.layout
        op = layout.operator("sna.dz_reset_tools_op",text=r"Reset Tools",emboss=True,depress=False,icon_value=0)
    except Exception as exc:
        print(str(exc) + " | Error in View3D Ht Header when adding to menu")


class SNA_AddonPreferences_DD142(bpy.types.AddonPreferences):
    bl_idname = 'dayz_modding_tools'
    dayz_tools_directory: bpy.props.StringProperty(name='DayZ Tools Directory',description='',subtype='DIR_PATH',options=set(),default='C:\\Program Files (x86)\\Steam\\steamapps\\common\\DayZ Tools\\')

    def draw(self, context):
        try:
            layout = self.layout
            layout.prop(context.preferences.addons['dayz_modding_tools'].preferences,'dayz_tools_directory',icon_value=0,text=r"DayZ Tools Directory",emboss=True,)
        except Exception as exc:
            print(str(exc) + " | Error in addon preferences")

def sn_prepend_panel_C8486(self,context):
    try:
        layout = self.layout
        box = layout.box()
        box.enabled = True
        box.alert = False
        box.scale_x = 1.0
        box.scale_y = 1.0
        box = box.box()
        box.enabled = True
        box.alert = False
        box.scale_x = 1.0
        box.scale_y = 1.0
        box.separator(factor=0.5)
        op = box.operator("sna.dz_convert_paa_op_",text=r"Convert PAA to TGA",emboss=True,depress=False,icon_value=0)
        op = box.operator("sna.dz_convert_material_op",text=r"Convert to DayZ Material",emboss=True,depress=False,icon_value=0)
        box.separator(factor=1.0)
    except Exception as exc:
        print(str(exc) + " | Error in Atbx Material Settings Panel when adding to panel")


#######   Functions
try: exec(r"functions['dz_mem_points'].clear()")
except Exception as exc: sn_handle_script_line_exception(exc, r"functions['dz_mem_points'].clear()")
try: exec(r"functions['dz_mem_point_name'] = ''")
except Exception as exc: sn_handle_script_line_exception(exc, r"functions['dz_mem_point_name'] = ''")
try: exec(r"functions['dz_list_of_survivor_bones'] = ['pelvis', 'launcher', 'weapon', 'propweaponbody', 'propweaponslide', 'propweaponmag', 'propweapon01', 'propweapon02', 'propweapon03', 'propweapon04', 'propweapon05', 'propweapon06', 'propweapon07', 'propweapon08', 'propweapon09', 'propweapon10', 'lefthipextra', 'righthipextra', 'propbeltleft', 'propbeltright', 'propbeltcenter', 'turningaxis', 'propbackpackmain', 'propbackpacktop', 'propbackpackextra', 'propbackpackleft', 'propbackpackright', 'spine', 'spine1', 'proprifleunderarm', 'spine2', 'proprifleback', 'propvestleft', 'propvestright', 'propvestfront', 'propvestlower', 'spine3', 'propvestupper', 'propvestback', 'neck', 'neck1', 'head', 'prophelmet', 'prophelmetvisor', 'propmouth', 'propmask', 'propglasses', 'prophelmetchin', 'propcamera1st', 'headcutscene', 'eyeleft', 'eyeright', 'face_browfrontleft', 'face_browfrontright', 'face_browmiddle', 'face_browsideleft', 'face_browsideright', 'face_cornerleft', 'face_cornerright', 'face_eyelidlowerleft', 'face_eyelidlowerright', 'face_eyelids', 'face_eyelidupperleft', 'face_eyelidupperright', 'face_forehead', 'face_cheekfrontleft', 'face_cheekfrontright', 'face_cheeksideleft', 'face_cheeksideright', 'face_cheekupperleft', 'face_cheekupperright', 'face_chin', 'face_chopleft', 'face_chopright', 'face_jawbone', 'face_jowl', 'face_liplowerleft', 'face_liplowermiddle', 'face_liplowerright', 'face_lipupperleft', 'face_lipuppermiddle', 'face_lipupperright', 'face_nostrilleft', 'face_nostrilright', 'face_tongue', 'beard', 'hair', 'leftshoulder', 'leftarm', 'leftarmextra', 'leftarmroll', 'leftelbowextra', 'leftforearm', 'leftforearmextra', 'leftforearmroll', 'leftwristextra', 'lefthand', 'prophandl', 'lefthandring', 'lefthandring1', 'lefthandring2', 'lefthandring3', 'lefthandpinky1', 'lefthandpinky2', 'lefthandpinky3', 'lefthandmiddle1', 'lefthandmiddle2', 'lefthandmiddle3', 'lefthandindex1', 'lefthandindex2', 'lefthandindex3', 'lefthandthumb1', 'lefthandthumb2', 'lefthandthumb3', 'rightshoulder', 'rightarm', 'rightarmextra', 'rightarmroll', 'rightelbowextra', 'rightforearm', 'rightforearmextra', 'rightforearmroll', 'rightwristextra', 'righthand', 'prophandr', 'righthandring', 'righthandring1', 'righthandring2', 'righthandring3', 'righthandpinky1', 'righthandpinky2', 'righthandpinky3', 'righthandmiddle1', 'righthandmiddle2', 'righthandmiddle3', 'righthandindex1', 'righthandindex2', 'righthandindex3', 'righthandthumb1', 'righthandthumb2', 'righthandthumb3', 'leftupleg', 'leftuplegroll', 'propthighleft', 'leftkneeextra', 'leftleg', 'leftlegroll', 'leftfoot', 'lefttoebase', 'rightupleg', 'rightuplegroll', 'propthighright', 'rightkneeextra', 'rightleg', 'rightlegroll', 'rightfoot', 'righttoebase', 'camera', 'righthand_dummy']")
except Exception as exc: sn_handle_script_line_exception(exc, r"functions['dz_list_of_survivor_bones'] = ['pelvis', 'launcher', 'weapon', 'propweaponbody', 'propweaponslide', 'propweaponmag', 'propweapon01', 'propweapon02', 'propweapon03', 'propweapon04', 'propweapon05', 'propweapon06', 'propweapon07', 'propweapon08', 'propweapon09', 'propweapon10', 'lefthipextra', 'righthipextra', 'propbeltleft', 'propbeltright', 'propbeltcenter', 'turningaxis', 'propbackpackmain', 'propbackpacktop', 'propbackpackextra', 'propbackpackleft', 'propbackpackright', 'spine', 'spine1', 'proprifleunderarm', 'spine2', 'proprifleback', 'propvestleft', 'propvestright', 'propvestfront', 'propvestlower', 'spine3', 'propvestupper', 'propvestback', 'neck', 'neck1', 'head', 'prophelmet', 'prophelmetvisor', 'propmouth', 'propmask', 'propglasses', 'prophelmetchin', 'propcamera1st', 'headcutscene', 'eyeleft', 'eyeright', 'face_browfrontleft', 'face_browfrontright', 'face_browmiddle', 'face_browsideleft', 'face_browsideright', 'face_cornerleft', 'face_cornerright', 'face_eyelidlowerleft', 'face_eyelidlowerright', 'face_eyelids', 'face_eyelidupperleft', 'face_eyelidupperright', 'face_forehead', 'face_cheekfrontleft', 'face_cheekfrontright', 'face_cheeksideleft', 'face_cheeksideright', 'face_cheekupperleft', 'face_cheekupperright', 'face_chin', 'face_chopleft', 'face_chopright', 'face_jawbone', 'face_jowl', 'face_liplowerleft', 'face_liplowermiddle', 'face_liplowerright', 'face_lipupperleft', 'face_lipuppermiddle', 'face_lipupperright', 'face_nostrilleft', 'face_nostrilright', 'face_tongue', 'beard', 'hair', 'leftshoulder', 'leftarm', 'leftarmextra', 'leftarmroll', 'leftelbowextra', 'leftforearm', 'leftforearmextra', 'leftforearmroll', 'leftwristextra', 'lefthand', 'prophandl', 'lefthandring', 'lefthandring1', 'lefthandring2', 'lefthandring3', 'lefthandpinky1', 'lefthandpinky2', 'lefthandpinky3', 'lefthandmiddle1', 'lefthandmiddle2', 'lefthandmiddle3', 'lefthandindex1', 'lefthandindex2', 'lefthandindex3', 'lefthandthumb1', 'lefthandthumb2', 'lefthandthumb3', 'rightshoulder', 'rightarm', 'rightarmextra', 'rightarmroll', 'rightelbowextra', 'rightforearm', 'rightforearmextra', 'rightforearmroll', 'rightwristextra', 'righthand', 'prophandr', 'righthandring', 'righthandring1', 'righthandring2', 'righthandring3', 'righthandpinky1', 'righthandpinky2', 'righthandpinky3', 'righthandmiddle1', 'righthandmiddle2', 'righthandmiddle3', 'righthandindex1', 'righthandindex2', 'righthandindex3', 'righthandthumb1', 'righthandthumb2', 'righthandthumb3', 'leftupleg', 'leftuplegroll', 'propthighleft', 'leftkneeextra', 'leftleg', 'leftlegroll', 'leftfoot', 'lefttoebase', 'rightupleg', 'rightuplegroll', 'propthighright', 'rightkneeextra', 'rightleg', 'rightlegroll', 'rightfoot', 'righttoebase', 'camera', 'righthand_dummy']")


#######   Operators
class SNA_OT_Dz_Select_Op(bpy.types.Operator):
    bl_idname = "sna.dz_select_op"
    bl_label = "DZ_Select_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_F8B85 = dzf_select(r"Cube", )
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Select_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Select_OP")
        return self.execute(context)


class SNA_OT_Dz_Deselect_Op(bpy.types.Operator):
    bl_idname = "sna.dz_deselect_op"
    bl_label = "DZ_Deselect_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_A9AAF = dzf_deselect()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Deselect_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Deselect_OP")
        return self.execute(context)


class SNA_OT_Dz_Create_Dayz_Material_Op(bpy.types.Operator):
    bl_idname = "sna.dz_create_dayz_material_op"
    bl_label = "DZ_Create_DayZ_Material_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return operators["dz_rvmat_create"]

    def execute(self, context):
        try:
            function_return_02B1A = dzf_create_dayz_material()
            operators["dz_rvmat_create"] = False
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Create_DayZ_Material_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Create_DayZ_Material_OP")
        return self.execute(context)


class SNA_OT_Dz_Skip_Geo_Lod_Op(bpy.types.Operator):
    bl_idname = "sna.dz_skip_geo_lod_op"
    bl_label = "DZ_Skip_Geo_Lod_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_42B84 = dzf_skip(r"show_create_geo_lod", r"show_finalize", )
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Skip_Geo_Lod_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Skip_Geo_Lod_OP")
        return self.execute(context)


class SNA_OT_Dz_Skip_Mem_Lod_Op(bpy.types.Operator):
    bl_idname = "sna.dz_skip_mem_lod_op"
    bl_label = "DZ_Skip_Mem_Lod_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_6556E = dzf_skip(r"show_create_mem_lod", r"show_create_geo_lod", )
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Skip_Mem_Lod_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Skip_Mem_Lod_OP")
        return self.execute(context)


class SNA_OT_Dz_Skip_Mem_Points_Op(bpy.types.Operator):
    bl_idname = "sna.dz_skip_mem_points_op"
    bl_label = "DZ_Skip_Mem_Points_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_20A7E = dzf_skip(r"show_create_mem_points", r"show_create_geo_lod", )
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Skip_Mem_Points_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Skip_Mem_Points_OP")
        return self.execute(context)


class SNA_OT_Dz_Confirm_Object_Type_Op(bpy.types.Operator):
    bl_idname = "sna.dz_confirm_object_type_op"
    bl_label = "DZ_Confirm_Object_Type_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_A751A = dzf_confirm_object_type()
            function_return_E339F = dzf_create_dayz_object()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Confirm_Object_Type_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Confirm_Object_Type_OP")
        return self.execute(context)


class SNA_OT_Dz_Create_Hidden_Selections_Op(bpy.types.Operator):
    bl_idname = "sna.dz_create_hidden_selections_op"
    bl_label = "DZ_Create_Hidden_Selections_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Create_Hidden_Selections_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            function_return_20FF6 = dzf_create_hidden_selections()
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Create_Hidden_Selections_OP")
        return self.execute(context)


class SNA_OT_Dz_Convert_Material_Op(bpy.types.Operator):
    bl_idname = "sna.dz_convert_material_op"
    bl_label = "DZ_Convert_Material_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_3DF6A = dzf_create_dayz_material()
            function_return_0E9CF = dzf_material_to_path()
            function_return_0ADF3 = dzf_convert_to_dayz_material()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Convert_Material_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Convert_Material_OP")
        return self.execute(context)


class SNA_OT_Dz_Create_Dayz_Config_Op(bpy.types.Operator):
    bl_idname = "sna.dz_create_dayz_config_op"
    bl_label = "DZ_Create_DayZ_Config_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return (bpy.context.scene.dz_path != r"" and bpy.context.scene.dz_mod != r"")

    def execute(self, context):
        try:
            function_return_EE5E0 = dzf_create_dayz_config()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Create_DayZ_Config_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Create_DayZ_Config_OP")
        return self.execute(context)


class SNA_OT_Dz_Create_Memory_Lod_Op(bpy.types.Operator):
    bl_idname = "sna.dz_create_memory_lod_op"
    bl_label = "DZ_Create_Memory_LOD_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_DFE56 = dzf_create_memory_lod()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Create_Memory_LOD_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Create_Memory_LOD_OP")
        return self.execute(context)


class SNA_OT_Dz_Create_Dayz_Object_Op(bpy.types.Operator):
    bl_idname = "sna.dz_create_dayz_object_op"
    bl_label = "DZ_Create_DayZ_Object_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_50847 = dzf_create_lods()
            try: exec(r"dayz_modding_tools['show_create_obj'] = False")
            except Exception as exc: sn_handle_script_line_exception(exc, r"dayz_modding_tools['show_create_obj'] = False")
            try: exec(r"dayz_modding_tools['show_create_mem_lod'] = True")
            except Exception as exc: sn_handle_script_line_exception(exc, r"dayz_modding_tools['show_create_mem_lod'] = True")
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Create_DayZ_Object_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Create_DayZ_Object_OP")
        return self.execute(context)


class SNA_OT_Dz_Create_Ce_Center_Op(bpy.types.Operator):
    bl_idname = "sna.dz_create_ce_center_op"
    bl_label = "DZ_Create_ce_center_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_BF37B = dzf_create_mem_point(r"ce_center", )
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Create_ce_center_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Create_ce_center_OP")
        return self.execute(context)


class SNA_OT_Dz_Create_Ce_Radius_Op(bpy.types.Operator):
    bl_idname = "sna.dz_create_ce_radius_op"
    bl_label = "DZ_Create_ce_radius_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_C57BA = dzf_create_mem_point(r"ce_radius", )
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Create_ce_radius_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Create_ce_radius_OP")
        return self.execute(context)


class SNA_OT_Dz_Create_Throwingimpulse_Op(bpy.types.Operator):
    bl_idname = "sna.dz_create_throwingimpulse_op"
    bl_label = "DZ_Create_throwingimpulse_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_D6F88 = dzf_create_mem_point(r"throwingimpulseposition", )
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Create_throwingimpulse_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Create_throwingimpulse_OP")
        return self.execute(context)


class SNA_OT_Dz_Create_Meleerangestart_Op(bpy.types.Operator):
    bl_idname = "sna.dz_create_meleerangestart_op"
    bl_label = "DZ_Create_meleerangestart_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_6C470 = dzf_create_mem_point(r"meleerangestart", )
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Create_meleerangestart_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Create_meleerangestart_OP")
        return self.execute(context)


class SNA_OT_Dz_Create_Invview_Op(bpy.types.Operator):
    bl_idname = "sna.dz_create_invview_op"
    bl_label = "DZ_Create_invview_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_7DE4C = dzf_create_mem_point(r"invview", )
            function_return_636E4 = dzf_create_invview_camera()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Create_invview_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Create_invview_OP")
        return self.execute(context)


class SNA_OT_Dz_Finish_Mem_Lod_Op(bpy.types.Operator):
    bl_idname = "sna.dz_finish_mem_lod_op"
    bl_label = "DZ_Finish_Mem_Lod_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_C4C73 = dzf_finish_mem_lod()
            try: exec(r"dayz_modding_tools['show_create_geo_lod'] = True")
            except Exception as exc: sn_handle_script_line_exception(exc, r"dayz_modding_tools['show_create_geo_lod'] = True")
            try: exec(r"dayz_modding_tools['show_create_mem_points'] = False")
            except Exception as exc: sn_handle_script_line_exception(exc, r"dayz_modding_tools['show_create_mem_points'] = False")
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Finish_Mem_Lod_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Finish_Mem_Lod_OP")
        return self.execute(context)


class SNA_OT_Dz_Create_Meleerangeend_Op(bpy.types.Operator):
    bl_idname = "sna.dz_create_meleerangeend_op"
    bl_label = "DZ_Create_meleerangeend_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_20244 = dzf_create_mem_point(r"meleerangeend", )
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Create_meleerangeend_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Create_meleerangeend_OP")
        return self.execute(context)


class SNA_OT_Dz_Create_Geo_Lod_Op(bpy.types.Operator):
    bl_idname = "sna.dz_create_geo_lod_op"
    bl_label = "DZ_Create_Geo_Lod_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_7E510 = dzf_create_geo_lod()
            try: exec(r"dayz_modding_tools['show_button_combine_geo']= True")
            except Exception as exc: sn_handle_script_line_exception(exc, r"dayz_modding_tools['show_button_combine_geo']= True")
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Create_Geo_Lod_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Create_Geo_Lod_OP")
        return self.execute(context)


class SNA_OT_Dz_Finish_Geo_Lod_Op(bpy.types.Operator):
    bl_idname = "sna.dz_finish_geo_lod_op"
    bl_label = "DZ_Finish_Geo_Lod_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_BB78B = dzf_finish_geo_lod()
            function_return_CB0B1 = dzf_skip(r"show_create_geo_lod", r"show_finalize", )
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Finish_Geo_Lod_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Finish_Geo_Lod_OP")
        return self.execute(context)


class SNA_OT_Dz_Create_Script_Op(bpy.types.Operator):
    bl_idname = "sna.dz_create_script_op"
    bl_label = "DZ_Create_Script_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Create_Script_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            function_return_71E4E = dzf_create_script()
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Create_Script_OP")
        return self.execute(context)


class SNA_OT_Dz_Done_Op(bpy.types.Operator):
    bl_idname = "sna.dz_done_op"
    bl_label = "DZ_Done_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_0711A = dzf_done()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Done_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Done_OP")
        return self.execute(context)


class SNA_OT_Dz_Create_Model_Cfg_Op(bpy.types.Operator):
    bl_idname = "sna.dz_create_model_cfg_op"
    bl_label = "DZ_Create_Model_CFG_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return bpy.context.scene.dz_object_name != r""

    def execute(self, context):
        try:
            function_return_C565F = dzf_create_model_cfg()
            if bpy.context.scene.dz_object_subtype == r"Pistol":
                bpy.context.scene.dz_hidden_selections = False
            else:
                pass
            if True == bpy.context.scene.dz_hidden_selections:
                function_return_321CD = dzf_create_hidden_selections()
            else:
                pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Create_Model_CFG_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Create_Model_CFG_OP")
        return self.execute(context)


class SNA_OT_Dz_Reset_Tools_Op(bpy.types.Operator):
    bl_idname = "sna.dz_reset_tools_op"
    bl_label = "DZ_Reset_Tools_OP"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_5211D = dzf_reset_tools()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Reset_Tools_OP")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Reset_Tools_OP")
        return self.execute(context)


class SNA_OT_Dz_Convert_Paa_Op_(bpy.types.Operator):
    bl_idname = "sna.dz_convert_paa_op_"
    bl_label = "DZ_Convert_PAA_OP "
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            function_return_57853 = dzf_convert_paa()
        except Exception as exc:
            print(str(exc) + " | Error in execute function of DZ_Convert_PAA_OP ")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of DZ_Convert_PAA_OP ")
        return self.execute(context)


class SNA_OT_Placeholder(bpy.types.Operator):
    bl_idname = "sna.placeholder"
    bl_label = "PlaceHolder"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of PlaceHolder")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of PlaceHolder")
        return self.execute(context)


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.dayz_modding_tools_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.dayz_modding_tools_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.dayz_modding_tools_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.dz_object_subtype = bpy.props.EnumProperty(name='DZ_Object_Subtype',description='',options=set(),items=[('Inventory Base', 'Inventory Base', 'This is my enum item'), ('Melee Weapon', 'Melee Weapon', 'This is my enum item'), ('Pistol', 'Pistol', 'This is my enum item')])
    bpy.types.Scene.dz_number_of_lods = bpy.props.IntProperty(name='DZ_Number_Of_Lods',description='',subtype='NONE',options=set(),default=1,min=0,max=5)
    bpy.types.Scene.dz_number_of_components = bpy.props.IntProperty(name='DZ_Number_Of_Components',description='',subtype='NONE',options=set(),default=1,min=1,max=100)
    bpy.types.Scene.dz_create_fire_geo = bpy.props.BoolProperty(name='DZ_Create_Fire_Geo',description='',options=set(),default=True)
    bpy.types.Scene.dz_create_view_geo = bpy.props.BoolProperty(name='DZ_Create_View_Geo',description='',options=set(),default=True)
    bpy.types.Scene.dz_object_name = bpy.props.StringProperty(name='DZ_Object_Name',description='',subtype='NONE',options=set(),default='')
    bpy.types.Scene.dz_type_of_object = bpy.props.EnumProperty(name='DZ_Type_Of_Object',description='',options=set(),items=[('Inventory_Base', 'Inventory_Base', ''), ('BaseballBat', 'BaseballBat', 'This is my enum item'), ('Colt1911_Base', 'Colt1911_Base', 'This is my enum item'), ('CZ75_Base', 'CZ75_Base', 'This is my enum item')])
    bpy.types.Scene.dz_sections = bpy.props.StringProperty(name='DZ_Sections',description='',subtype='NONE',options=set(),default='')
    bpy.types.Scene.dz_hidden_selections = bpy.props.BoolProperty(name='DZ_Hidden_Selections?',description='',options=set(),default=True)
    bpy.types.Scene.dz_mod = bpy.props.StringProperty(name='DZ_MOD',description='',subtype='NONE',options=set(),default='')
    bpy.types.Scene.dz_path = bpy.props.StringProperty(name='DZ_PATH',description='',subtype='NONE',options=set(),update=update_dz_path,default='')
    bpy.types.Scene.dz_material = bpy.props.BoolProperty(name='DZ_Material?',description='',options=set(),default=False)
    bpy.types.Scene.dz_drive = bpy.props.StringProperty(name='DZ_Drive',description='',subtype='NONE',options=set(),default='P:\\')
    bpy.types.Scene.dz_asset_path = bpy.props.StringProperty(name='DZ_Asset_Path',description='',subtype='FILE_PATH',options=set(),default='')

def sn_unregister_properties():
    del bpy.types.Scene.dz_object_subtype
    del bpy.types.Scene.dz_number_of_lods
    del bpy.types.Scene.dz_number_of_components
    del bpy.types.Scene.dz_create_fire_geo
    del bpy.types.Scene.dz_create_view_geo
    del bpy.types.Scene.dz_object_name
    del bpy.types.Scene.dz_type_of_object
    del bpy.types.Scene.dz_sections
    del bpy.types.Scene.dz_hidden_selections
    del bpy.types.Scene.dz_mod
    del bpy.types.Scene.dz_path
    del bpy.types.Scene.dz_material
    del bpy.types.Scene.dz_drive
    del bpy.types.Scene.dz_asset_path


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_PT_Memory_Lod_19419)
    bpy.utils.register_class(SNA_PT_Geo_Lods_ADAC9)
    bpy.utils.register_class(SNA_PT_DayZ_Object_Type_17CBC)
    bpy.utils.register_class(SNA_PT_Create_DayZ_Object_351D7)
    bpy.utils.register_class(SNA_PT_DayZ_48213)
    bpy.utils.register_class(SNA_PT_Finalize_7DC5D)
    bpy.utils.register_class(SNA_PT_Memory_Lod_9CBC5)
    bpy.utils.register_class(SNA_PT_Memory_Lod_7A506)
    bpy.utils.register_class(SNA_PT_Memory_Lod_87AB4)
    bpy.utils.register_class(SNA_AddonPreferences_DD142)
    bpy.utils.register_class(SNA_OT_Dz_Select_Op)
    bpy.utils.register_class(SNA_OT_Dz_Deselect_Op)
    bpy.utils.register_class(SNA_OT_Dz_Create_Dayz_Material_Op)
    bpy.utils.register_class(SNA_OT_Dz_Skip_Geo_Lod_Op)
    bpy.utils.register_class(SNA_OT_Dz_Skip_Mem_Lod_Op)
    bpy.utils.register_class(SNA_OT_Dz_Skip_Mem_Points_Op)
    bpy.utils.register_class(SNA_OT_Dz_Confirm_Object_Type_Op)
    bpy.utils.register_class(SNA_OT_Dz_Create_Hidden_Selections_Op)
    bpy.utils.register_class(SNA_OT_Dz_Convert_Material_Op)
    bpy.utils.register_class(SNA_OT_Dz_Create_Dayz_Config_Op)
    bpy.utils.register_class(SNA_OT_Dz_Create_Memory_Lod_Op)
    bpy.utils.register_class(SNA_OT_Dz_Create_Dayz_Object_Op)
    bpy.utils.register_class(SNA_OT_Dz_Create_Ce_Center_Op)
    bpy.utils.register_class(SNA_OT_Dz_Create_Ce_Radius_Op)
    bpy.utils.register_class(SNA_OT_Dz_Create_Throwingimpulse_Op)
    bpy.utils.register_class(SNA_OT_Dz_Create_Meleerangestart_Op)
    bpy.utils.register_class(SNA_OT_Dz_Create_Invview_Op)
    bpy.utils.register_class(SNA_OT_Dz_Finish_Mem_Lod_Op)
    bpy.utils.register_class(SNA_OT_Dz_Create_Meleerangeend_Op)
    bpy.utils.register_class(SNA_OT_Dz_Create_Geo_Lod_Op)
    bpy.utils.register_class(SNA_OT_Dz_Finish_Geo_Lod_Op)
    bpy.utils.register_class(SNA_OT_Dz_Create_Script_Op)
    bpy.utils.register_class(SNA_OT_Dz_Done_Op)
    bpy.utils.register_class(SNA_OT_Dz_Create_Model_Cfg_Op)
    bpy.utils.register_class(SNA_OT_Dz_Reset_Tools_Op)
    bpy.utils.register_class(SNA_OT_Dz_Convert_Paa_Op_)
    bpy.utils.register_class(SNA_OT_Placeholder)
    bpy.types.VIEW3D_HT_header.append(sn_append_menu_4959B)
    bpy.types.ATBX_PT_material_settings_panel.prepend(sn_prepend_panel_C8486)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.types.ATBX_PT_material_settings_panel.remove(sn_prepend_panel_C8486)
    bpy.types.VIEW3D_HT_header.remove(sn_append_menu_4959B)
    bpy.utils.unregister_class(SNA_OT_Placeholder)
    bpy.utils.unregister_class(SNA_OT_Dz_Convert_Paa_Op_)
    bpy.utils.unregister_class(SNA_OT_Dz_Reset_Tools_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Create_Model_Cfg_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Done_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Create_Script_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Finish_Geo_Lod_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Create_Geo_Lod_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Create_Meleerangeend_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Finish_Mem_Lod_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Create_Invview_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Create_Meleerangestart_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Create_Throwingimpulse_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Create_Ce_Radius_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Create_Ce_Center_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Create_Dayz_Object_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Create_Memory_Lod_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Create_Dayz_Config_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Convert_Material_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Create_Hidden_Selections_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Confirm_Object_Type_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Skip_Mem_Points_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Skip_Mem_Lod_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Skip_Geo_Lod_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Create_Dayz_Material_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Deselect_Op)
    bpy.utils.unregister_class(SNA_OT_Dz_Select_Op)
    bpy.utils.unregister_class(SNA_AddonPreferences_DD142)
    bpy.utils.unregister_class(SNA_PT_Memory_Lod_87AB4)
    bpy.utils.unregister_class(SNA_PT_Memory_Lod_7A506)
    bpy.utils.unregister_class(SNA_PT_Memory_Lod_9CBC5)
    bpy.utils.unregister_class(SNA_PT_Finalize_7DC5D)
    bpy.utils.unregister_class(SNA_PT_DayZ_48213)
    bpy.utils.unregister_class(SNA_PT_Create_DayZ_Object_351D7)
    bpy.utils.unregister_class(SNA_PT_DayZ_Object_Type_17CBC)
    bpy.utils.unregister_class(SNA_PT_Geo_Lods_ADAC9)
    bpy.utils.unregister_class(SNA_PT_Memory_Lod_19419)