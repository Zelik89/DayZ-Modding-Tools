# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "DayZ Modding Tools",
    "description": "",
    "author": "Zelik",
    "version": (1, 0, 0),
    "blender": (2, 92, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "3D View"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
dayz_modding_tools = {
    "type_chosen": False, 
    "show_create_main": False, 
    "show_create_mem": False, 
    "mem_generated": False, 
    "invview_created": False, 
    "ce_center_created": False, 
    "ce_radius_created": False, 
    "range_start_created": False, 
    "range_end_created": False, 
    "throwing_impulse_created": False, 
    "show_create_geo": False, 
    "geo_created": False, 
    "geo_done": False, 
    "show_finalize": False, 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
###############   EVALUATED CODE
#######   DayZ Modding Tools
class SNA_OT_Done_Creating_Object(bpy.types.Operator):
    bl_idname = "sna.done_creating_object"
    bl_label = "Done Creating Object"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Done Creating Object")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            dayz_modding_tools["show_create_mem"] = True
            dayz_modding_tools["show_create_main"] = False
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Done Creating Object")
        return self.execute(context)


class SNA_OT_Create_Resolution_Lods(bpy.types.Operator):
    bl_idname = "sna.create_resolution_lods"
    bl_label = "Create Resolution Lods"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create Resolution Lods")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # Create_LODs.py Script Start
            import bpy
            from math import radians
            num_of_lods = bpy.context.scene.number_of_lods
            obj_list = []
            original = bpy.context.active_object
            bpy.ops.object.select_all(action='DESELECT')
            if bpy.context.scene.type_of_object == 'Inventory_Base':
                Object = bpy.context.scene.objects["0"]
                bpy.context.view_layer.objects.active = Object
                Object.select_set(True)   
                for i in range(1, num_of_lods + 1):               
                    bpy.ops.object.duplicate(linked=False)
                    active = bpy.context.active_object
                    active.name = str(i)
                    bpy.data.objects[active.name].armaObjProps.isArmaObject = True
                    bpy.data.objects[active.name].armaObjProps.lod = '-1.0'
                    bpy.data.objects[active.name].armaObjProps.lodDistance = float(i)
                    obj_list.append(active)
                index = 5
                for i in obj_list:
                        Obj = i.modifiers.new("Decimate",'DECIMATE')
                        Obj.decimate_type = "DISSOLVE"
                        Obj.angle_limit = radians(index)
                        index = index + 5
            if bpy.context.scene.type_of_object == 'Melee_Weapon':
                Object = bpy.context.scene.objects["View Pilot"]
                bpy.context.view_layer.objects.active = Object
                Object.select_set(True)   
                for i in range(2, num_of_lods + 2):      
                    bpy.ops.object.duplicate(linked=False)
                    active = bpy.context.active_object
                    active.name = str(i)
                    bpy.data.objects[active.name].armaObjProps.isArmaObject = True
                    bpy.data.objects[active.name].armaObjProps.lod = '-1.0'
                    bpy.data.objects[active.name].armaObjProps.lodDistance = float(i)
                    obj_list.append(active)
                index = 5
                for i in obj_list:
                        Obj = i.modifiers.new("Decimate",'DECIMATE')
                        Obj.decimate_type = "DISSOLVE"
                        Obj.angle_limit = radians(index)
                        index = index + 5
            pass # Create_LODs.py Script End
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create Resolution Lods")
        return self.execute(context)


class SNA_OT_Create_Dayz_Object(bpy.types.Operator):
    bl_idname = "sna.create_dayz_object"
    bl_label = "Create DayZ Object"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return bpy.context.active_object.type=="MESH"

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create DayZ Object")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # Create_DayZ_Object.py Script Start
            import bpy
            if bpy.context.scene.type_of_object == 'Inventory_Base':
                original = bpy.context.active_object
                bpy.ops.object.duplicate(linked=False)
                active = bpy.context.active_object
                active.name = "0"
                bpy.data.objects[active.name].armaObjProps.isArmaObject = True
                bpy.data.objects[active.name].armaObjProps.lod = '-1.0'
                bpy.data.objects[active.name].armaObjProps.lodDistance = 0.00
                bpy.ops.object.select_all(action='INVERT')
                bpy.ops.object.delete()
                bpy.ops.object.select_all(action='SELECT')
            if bpy.context.scene.type_of_object == 'Melee_Weapon':
                original = bpy.context.active_object
                bpy.ops.object.duplicate(linked=False)
                active = bpy.context.active_object
                active.name = "View Pilot"
                bpy.data.objects[active.name].armaObjProps.isArmaObject = True
                bpy.data.objects[active.name].armaObjProps.lod = '1.100e+3'
                bpy.ops.object.select_all(action='INVERT')
                bpy.ops.object.delete()
                bpy.ops.object.select_all(action='SELECT')
            pass # Create_DayZ_Object.py Script End
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create DayZ Object")
        return self.execute(context)


class SNA_PT_Create_DayZ_Object_B4F59(bpy.types.Panel):
    bl_label = "Create DayZ Object"
    bl_idname = "SNA_PT_Create_DayZ_Object_B4F59"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return dayz_modding_tools["show_create_main"]

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Create DayZ Object panel header")

    def draw(self, context):
        try:
            layout = self.layout
            op = layout.operator("sna.create_dayz_object",text=r"Create DayZ Object",emboss=True,depress=False,icon_value=0)
            row = layout.row(align=False)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'number_of_lods',text=r"Number Of Lods",emboss=True,slider=False,)
            op = row.operator("sna.create_resolution_lods",text=r"Create Resolution Lods",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.done_creating_object",text=r"Done",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Create DayZ Object panel")


class SNA_PT_Create_Memory_Lod_8EC32(bpy.types.Panel):
    bl_label = "Create Memory Lod"
    bl_idname = "SNA_PT_Create_Memory_Lod_8EC32"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return dayz_modding_tools["show_create_mem"]

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Create Memory Lod panel header")

    def draw(self, context):
        try:
            layout = self.layout
            op = layout.operator("sna.create_memory_lod",text=r"Create Memory Lod",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Create Memory Lod panel")


class SNA_OT_Create_Memory_Lod(bpy.types.Operator):
    bl_idname = "sna.create_memory_lod"
    bl_label = "Create Memory Lod"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create Memory Lod")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # Create_Memory_Lod.py Script Start
            import bpy,bmesh
            bpy.ops.object.select_all(action='DESELECT')
            if bpy.context.scene.type_of_object == 'Inventory_Base':
                Object = bpy.context.scene.objects["0"]
                bpy.context.view_layer.objects.active = Object
                Object.select_set(True) 
            if bpy.context.scene.type_of_object == 'Melee_Weapon':
                Object = bpy.context.scene.objects["View Pilot"]
                bpy.context.view_layer.objects.active = Object
                Object.select_set(True) 
            bpy.ops.object.duplicate(linked=False)
            active = bpy.context.active_object
            active.name = "Memory"
            active.modifiers.clear()
            bpy.data.objects[active.name].armaObjProps.isArmaObject = True
            bpy.data.objects[active.name].armaObjProps.lod = '1.000e+15'
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
            #create a cube for the bounding box
            bpy.ops.mesh.primitive_cube_add() 
            #our new cube is now the active object, so we can keep track of it in a variable:
            bound_box = bpy.context.active_object 
            #copy transforms
            bound_box.dimensions = active.dimensions
            bound_box.location = active.location
            bound_box.rotation_euler = active.rotation_euler
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True, properties=True)
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS')
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.view_layer.objects.active = bpy.data.objects[active.name]
            bpy.ops.object.editmode_toggle()
            mesh = bmesh.from_edit_mesh(active.data)
            for v in mesh.verts:
                v.select = True
            bpy.ops.mesh.delete(type='VERT')
            bpy.ops.object.editmode_toggle()
            bpy.context.scene.objects[bound_box.name].select_set(True)
            bpy.context.scene.objects[active.name].select_set(True)
            bpy.context.view_layer.objects.active = bpy.data.objects[active.name]
            bpy.ops.object.join()
            box_verts = [vert.co for vert in active.data.vertices]
            boundingbox_max = bpy.context.active_object.vertex_groups.new(name='boundingbox_max')
            bb_max = [1]
            boundingbox_max.add(bb_max, 1.0, 'ADD')
            boundingbox_min = bpy.context.active_object.vertex_groups.new(name='boundingbox_min')
            bb_min = [6]
            boundingbox_min.add(bb_min, 1.0, 'ADD')
            pass # Create_Memory_Lod.py Script End
            dayz_modding_tools["show_create_mem"] = False
            dayz_modding_tools["mem_generated"] = True
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create Memory Lod")
        return self.execute(context)


class SNA_PT_Choose_Object_Type_E079D(bpy.types.Panel):
    bl_label = "Choose Object Type"
    bl_idname = "SNA_PT_Choose_Object_Type_E079D"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return not dayz_modding_tools["type_chosen"]

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Choose Object Type panel header")

    def draw(self, context):
        try:
            layout = self.layout
            layout.prop(bpy.context.scene,'type_of_object',icon_value=0,text=r"Type Of Object",emboss=True,expand=False,)
            op = layout.operator("sna.choose_type",text=r"Done",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Choose Object Type panel")


class SNA_OT_Choose_Type(bpy.types.Operator):
    bl_idname = "sna.choose_type"
    bl_label = "Choose Type"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Choose Type")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            dayz_modding_tools["type_chosen"] = True
            dayz_modding_tools["show_create_main"] = True
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Choose Type")
        return self.execute(context)


class SNA_PT_Create_Memory_Lod_8E26E(bpy.types.Panel):
    bl_label = "Create Memory Lod"
    bl_idname = "SNA_PT_Create_Memory_Lod_8E26E"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return (dayz_modding_tools["mem_generated"] and r"Inventory_Base" == bpy.context.scene.type_of_object)

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Create Memory Lod panel header")

    def draw(self, context):
        try:
            layout = self.layout
            op = layout.operator("sna.create_invview",text=r"Create Invview",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.create_ce_center",text=r"Create ce_center",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.create_ce_radius",text=r"Create ce_radius",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.inview_done",text=r"Done",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Create Memory Lod panel")


class SNA_PT_Create_Memory_Lod_468AA(bpy.types.Panel):
    bl_label = "Create Memory Lod"
    bl_idname = "SNA_PT_Create_Memory_Lod_468AA"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return (dayz_modding_tools["mem_generated"] and r"Melee_Weapon" == bpy.context.scene.type_of_object)

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Create Memory Lod panel header")

    def draw(self, context):
        try:
            layout = self.layout
            op = layout.operator("sna.create_invview",text=r"Create Invview",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.create_ce_center",text=r"Create ce_center",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.create_ce_radius",text=r"Create ce_radius",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.create_range_start",text=r"Create meleerangestart",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.create_range_end",text=r"Create meleerangeend",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.create_throwing_impulse",text=r"Create throwingimpulseposition",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.inview_done",text=r"Done",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Create Memory Lod panel")


class SNA_OT_Create_Invview(bpy.types.Operator):
    bl_idname = "sna.create_invview"
    bl_label = "Create Invview"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return not dayz_modding_tools["invview_created"]

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create Invview")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # Create_Inview.py Script Start
            import bpy
            from mathutils import Vector
            bpy.ops.object.select_all(action='DESELECT')
            Object = bpy.context.scene.objects["Memory"]
            bpy.context.view_layer.objects.active = Object
            Object.select_set(True)
            # get the current scene
            scn = bpy.context.scene
            # create a mesh data block
            mymesh = bpy.data.meshes.new('invview')
            # define some vertices
            verts = [Vector((0,  0, 0))]
            edges = []
            faces = []
            # add the vertices to the mesh
            mymesh.from_pydata(verts, edges, faces)
            # create an object that uses the mesh data
            myobj = bpy.data.objects.new('invview', mymesh)
            # link the object to the scene
            scn.collection.objects.link(myobj)
            bpy.ops.view3d.snap_cursor_to_active()
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.scene.objects[myobj.name].select_set(True)
            bpy.context.view_layer.objects.active = bpy.data.objects[myobj.name]
            box_verts = [vert.co for vert in myobj.data.vertices]
            vertexgroup = bpy.context.active_object.vertex_groups.new(name=myobj.name)
            vertex = [0]
            vertexgroup.add(vertex, 1.0, 'ADD')
            for area in bpy.context.screen.areas:
                if area.type == 'VIEW_3D':
                    override = bpy.context.copy()
                    override['area'] = area
                    bpy.ops.view3d.view_axis(override, type='TOP')
                    break
            # create the first camera
            cam1 = bpy.data.cameras.new("invview camera")
            cam1.lens = 10
            # create the first camera object
            cam_obj1 = bpy.data.objects.new("invview camera", cam1)
            cam_obj1.location = (0, -5, 5)
            cam_obj1.rotation_euler = (45, 0, 0)
            scn.collection.objects.link(cam_obj1)
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.view_layer.objects.active = bpy.data.objects[cam_obj1.name]
            bpy.context.scene.objects[cam_obj1.name].select_set(True)
            pass # Create_Inview.py Script End
            dayz_modding_tools["invview_created"] = True
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create Invview")
        return self.execute(context)


class SNA_OT_Create_Ce_Center(bpy.types.Operator):
    bl_idname = "sna.create_ce_center"
    bl_label = "Create_CE_Center"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return not dayz_modding_tools["ce_center_created"]

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create_CE_Center")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # Create_CE_Center.py Script Start
            import bpy
            from mathutils import Vector
            # get the current scene
            scn = bpy.context.scene
            # create a mesh data block
            mymesh = bpy.data.meshes.new('ce_center')
            # define some vertices
            verts = [Vector((0,  0, 0))]
            edges = []
            faces = []
            # add the vertices to the mesh
            mymesh.from_pydata(verts, edges, faces)
            # create an object that uses the mesh data
            myobj = bpy.data.objects.new('ce_center', mymesh)
            # link the object to the scene
            scn.collection.objects.link(myobj)
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.scene.objects[myobj.name].select_set(True)
            bpy.context.view_layer.objects.active = bpy.data.objects[myobj.name]
            box_verts = [vert.co for vert in myobj.data.vertices]
            vertexgroup = bpy.context.active_object.vertex_groups.new(name=myobj.name)
            vertex = [0]
            vertexgroup.add(vertex, 1.0, 'ADD')
            pass # Create_CE_Center.py Script End
            dayz_modding_tools["ce_center_created"] = True
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create_CE_Center")
        return self.execute(context)


class SNA_OT_Inview_Done(bpy.types.Operator):
    bl_idname = "sna.inview_done"
    bl_label = "Inview_Done"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass # Done_Invview.py Script Start
            import bpy
            bpy.ops.object.select_all(action='DESELECT')
            camera = bpy.context.active_object
            bpy.ops.view3d.snap_cursor_to_active()
            lod = bpy.context.scene.objects["invview"]
            bpy.context.view_layer.objects.active = lod
            lod.select_set(True)
            bpy.ops.view3d.snap_selected_to_cursor()
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
            bpy.ops.object.select_all(action='DESELECT')
            camera_to_delete = bpy.context.scene.objects["invview camera"]
            bpy.context.view_layer.objects.active = camera_to_delete
            camera_to_delete.select_set(True)
            bpy.ops.object.delete()
            mem = bpy.context.scene.objects["Memory"]
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.scene.objects[lod.name].select_set(True)
            bpy.context.scene.objects[mem.name].select_set(True)
            bpy.context.view_layer.objects.active = bpy.data.objects[mem.name]
            bpy.ops.object.join()
            bpy.ops.view3d.snap_cursor_to_center()
            pass # Done_Invview.py Script End
            pass # Done_Other_Mem_Points.py Script Start
            import bpy
            from mathutils import Vector
            obj_list = ["ce_center", "ce_radius", "meleerangestart","meleerangeend","throwingimpulseposition"]
            for i in obj_list:
                bpy.ops.object.select_all(action='DESELECT')
                lod = bpy.context.scene.objects[i]
                if lod:
                    print("lod is " + str(lod))
                    bpy.context.view_layer.objects.active = lod
                    lod.select_set(True)
                    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                    bpy.ops.object.select_all(action='DESELECT')
                    mem = bpy.context.scene.objects["Memory"]
                    bpy.ops.object.select_all(action='DESELECT')
                    bpy.context.scene.objects[lod.name].select_set(True)
                    bpy.context.scene.objects[mem.name].select_set(True)
                    bpy.context.view_layer.objects.active = bpy.data.objects[mem.name]
                    bpy.ops.object.join()
            pass # Done_Other_Mem_Points.py Script End
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Inview_Done")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            dayz_modding_tools["mem_generated"] = False
            dayz_modding_tools["show_create_geo"] = True
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Inview_Done")
        return self.execute(context)


class SNA_OT_Create_Range_End(bpy.types.Operator):
    bl_idname = "sna.create_range_end"
    bl_label = "Create_Range_End"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return not dayz_modding_tools["range_end_created"]

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create_Range_End")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # Create_Range_End.py Script Start
            import bpy
            from mathutils import Vector
            # get the current scene
            scn = bpy.context.scene
            # create a mesh data block
            mymesh = bpy.data.meshes.new('meleerangeend')
            # define some vertices
            verts = [Vector((0,  0, 0))]
            edges = []
            faces = []
            # add the vertices to the mesh
            mymesh.from_pydata(verts, edges, faces)
            # create an object that uses the mesh data
            myobj = bpy.data.objects.new('meleerangeend', mymesh)
            # link the object to the scene
            scn.collection.objects.link(myobj)
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.scene.objects[myobj.name].select_set(True)
            bpy.context.view_layer.objects.active = bpy.data.objects[myobj.name]
            box_verts = [vert.co for vert in myobj.data.vertices]
            vertexgroup = bpy.context.active_object.vertex_groups.new(name=myobj.name)
            vertex = [0]
            vertexgroup.add(vertex, 1.0, 'ADD')
            pass # Create_Range_End.py Script End
            dayz_modding_tools["range_end_created"] = True
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create_Range_End")
        return self.execute(context)


class SNA_OT_Create_Throwing_Impulse(bpy.types.Operator):
    bl_idname = "sna.create_throwing_impulse"
    bl_label = "Create_Throwing_Impulse"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return not dayz_modding_tools["throwing_impulse_created"]

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create_Throwing_Impulse")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # Create_Throwing_Impulse.py Script Start
            import bpy
            from mathutils import Vector
            # get the current scene
            scn = bpy.context.scene
            # create a mesh data block
            mymesh = bpy.data.meshes.new('throwingimpulseposition')
            # define some vertices
            verts = [Vector((0,  0, 0))]
            edges = []
            faces = []
            # add the vertices to the mesh
            mymesh.from_pydata(verts, edges, faces)
            # create an object that uses the mesh data
            myobj = bpy.data.objects.new('throwingimpulseposition', mymesh)
            # link the object to the scene
            scn.collection.objects.link(myobj)
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.scene.objects[myobj.name].select_set(True)
            bpy.context.view_layer.objects.active = bpy.data.objects[myobj.name]
            box_verts = [vert.co for vert in myobj.data.vertices]
            vertexgroup = bpy.context.active_object.vertex_groups.new(name=myobj.name)
            vertex = [0]
            vertexgroup.add(vertex, 1.0, 'ADD')
            pass # Create_Throwing_Impulse.py Script End
            dayz_modding_tools["throwing_impulse_created"] = True
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create_Throwing_Impulse")
        return self.execute(context)


class SNA_OT_Create_Range_Start(bpy.types.Operator):
    bl_idname = "sna.create_range_start"
    bl_label = "Create_Range_Start"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return not dayz_modding_tools["range_start_created"]

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create_Range_Start")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # Create_Range_Start.py Script Start
            import bpy
            from mathutils import Vector
            # get the current scene
            scn = bpy.context.scene
            # create a mesh data block
            mymesh = bpy.data.meshes.new('meleerangestart')
            # define some vertices
            verts = [Vector((0,  0, 0))]
            edges = []
            faces = []
            # add the vertices to the mesh
            mymesh.from_pydata(verts, edges, faces)
            # create an object that uses the mesh data
            myobj = bpy.data.objects.new('meleerangestart', mymesh)
            # link the object to the scene
            scn.collection.objects.link(myobj)
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.scene.objects[myobj.name].select_set(True)
            bpy.context.view_layer.objects.active = bpy.data.objects[myobj.name]
            box_verts = [vert.co for vert in myobj.data.vertices]
            vertexgroup = bpy.context.active_object.vertex_groups.new(name=myobj.name)
            vertex = [0]
            vertexgroup.add(vertex, 1.0, 'ADD')
            pass # Create_Range_Start.py Script End
            dayz_modding_tools["range_start_created"] = True
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create_Range_Start")
        return self.execute(context)


class SNA_OT_Create_Ce_Radius(bpy.types.Operator):
    bl_idname = "sna.create_ce_radius"
    bl_label = "Create_CE_Radius"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return not dayz_modding_tools["ce_radius_created"]

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create_CE_Radius")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # Create_CE_Radius.py Script Start
            import bpy
            from mathutils import Vector
            # get the current scene
            scn = bpy.context.scene
            # create a mesh data block
            mymesh = bpy.data.meshes.new('ce_radius')
            # define some vertices
            verts = [Vector((0,  0, 0))]
            edges = []
            faces = []
            # add the vertices to the mesh
            mymesh.from_pydata(verts, edges, faces)
            # create an object that uses the mesh data
            myobj = bpy.data.objects.new('ce_radius', mymesh)
            # link the object to the scene
            scn.collection.objects.link(myobj)
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.scene.objects[myobj.name].select_set(True)
            bpy.context.view_layer.objects.active = bpy.data.objects[myobj.name]
            box_verts = [vert.co for vert in myobj.data.vertices]
            vertexgroup = bpy.context.active_object.vertex_groups.new(name=myobj.name)
            vertex = [0]
            vertexgroup.add(vertex, 1.0, 'ADD')
            pass # Create_CE_Radius.py Script End
            dayz_modding_tools["ce_radius_created"] = True
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create_CE_Radius")
        return self.execute(context)


class SNA_PT_Create_Geometry_Lods_D9536(bpy.types.Panel):
    bl_label = "Create Geometry Lods"
    bl_idname = "SNA_PT_Create_Geometry_Lods_D9536"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return dayz_modding_tools["show_create_geo"]

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Create Geometry Lods panel header")

    def draw(self, context):
        try:
            layout = self.layout
            row = layout.row(align=False)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            row.prop(bpy.context.scene,'number_of_components',text=r"Number Of Components",emboss=True,slider=False,)
            row = layout.row(align=False)
            row.enabled = True
            row.alert = False
            row.scale_x = 1.0
            row.scale_y = 1.0
            op = row.operator("sna.create_geometry_lod",text=r"Create Geometry Lod",emboss=True,depress=False,icon_value=0)
            op = row.operator("sna.geo_lod_done",text=r"Done",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.create_fire_gometry_lod",text=r"Create Fire Geometry",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.create_view_geometry_lod",text=r"Create View Geometry",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.geos_done",text=r"Done",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Create Geometry Lods panel")


class SNA_OT_Geos_Done(bpy.types.Operator):
    bl_idname = "sna.geos_done"
    bl_label = "Geos_Done"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Geos_Done")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass # All_Geos_Done.py Script Start
            import bpy
            bpy.ops.object.select_all(action='DESELECT')
            Object = bpy.context.scene.objects["Geometry"]
            bpy.context.view_layer.objects.active = Object
            Object.select_set(True)
            bpy.ops.armatoolbox.add_prop()
            bpy.data.objects[Object.name].armaObjProps.namedProps[0].name = 'autocenter'
            bpy.data.objects[Object.name].armaObjProps.namedProps[0].value = '0'
            pass # All_Geos_Done.py Script End
            dayz_modding_tools["show_create_geo"] = False
            dayz_modding_tools["show_finalize"] = True
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Geos_Done")
        return self.execute(context)


class SNA_OT_Geo_Lod_Done(bpy.types.Operator):
    bl_idname = "sna.geo_lod_done"
    bl_label = "Geo Lod Done"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass # Done_Geo.py Script Start
            import bpy,bmesh
            import ArmaTools
            from math import radians
            num_of_components = bpy.context.scene.number_of_components
            obj_list = []
            original = bpy.context.active_object
            bpy.ops.object.select_all(action='DESELECT')
            for i in range(0, num_of_components):
                Geo = bpy.context.scene.objects["Geo " + str(i)]             
                bpy.context.scene.objects[Geo.name].select_set(True) 
            bpy.context.view_layer.objects.active = bpy.data.objects['Geo 0']
            Geo = bpy.data.objects['Geo 0']
            Geo.name = "Geometry"
            bpy.ops.object.join()
            bpy.ops.armatoolbox.create_components()
            bpy.ops.object.editmode_toggle()
            mesh = bmesh.from_edit_mesh(Geo.data)
            for v in mesh.verts:
                v.select = True
            mass = 1.0
            ArmaTools.distributeVertexMass(Geo, mass)
            bpy.ops.object.editmode_toggle()
            #bpy.ops.object.transform_apply(location=True, rotation=True, scale=True, properties=True)
            #bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS')
            pass # Done_Geo.py Script End
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Geo Lod Done")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            dayz_modding_tools["geo_done"] = True
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Geo Lod Done")
        return self.execute(context)


class SNA_OT_Create_Fire_Gometry_Lod(bpy.types.Operator):
    bl_idname = "sna.create_fire_gometry_lod"
    bl_label = "Create Fire Gometry Lod"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return dayz_modding_tools["geo_done"]

    def execute(self, context):
        try:
            pass # Create_Fire_Geo.py Script Start
            import bpy
            import ArmaTools
            bpy.ops.object.select_all(action='DESELECT')
            Object = bpy.context.scene.objects["Geometry"]
            bpy.context.view_layer.objects.active = Object
            Object.select_set(True)
            bpy.ops.object.duplicate(linked=False)
            active = bpy.context.active_object
            active.name = "Fire Geometry" 
            bpy.data.objects[active.name].armaObjProps.isArmaObject = True
            bpy.data.objects[active.name].armaObjProps.lod = '7.000e+15'
            pass # Create_Fire_Geo.py Script End
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create Fire Gometry Lod")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create Fire Gometry Lod")
        return self.execute(context)


class SNA_OT_Create_Geometry_Lod(bpy.types.Operator):
    bl_idname = "sna.create_geometry_lod"
    bl_label = "Create Geometry Lod"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass # Create_Geo_Lod.py Script Start
            import bpy
            num_of_components = bpy.context.scene.number_of_components
            obj_list = []
            bpy.ops.object.select_all(action='DESELECT')
            mem = bpy.context.scene.objects["Memory"]
            for i in range(0, num_of_components):               
                bpy.ops.mesh.primitive_cube_add()
                active = bpy.context.active_object
                active.name = "Geo " + str(i) 
                #copy transforms
                active.dimensions = mem.dimensions
                active.location = mem.location
                active.rotation_euler = mem.rotation_euler
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True, properties=True)
                bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS')
                bpy.data.objects[active.name].armaObjProps.isArmaObject = True
                bpy.data.objects[active.name].armaObjProps.lod = '1.000e+13'
            pass # Create_Geo_Lod.py Script End
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create Geometry Lod")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            dayz_modding_tools["geo_done"] = False
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create Geometry Lod")
        return self.execute(context)


class SNA_OT_Create_View_Geometry_Lod(bpy.types.Operator):
    bl_idname = "sna.create_view_geometry_lod"
    bl_label = "Create View Geometry Lod"
    bl_description = "Create View Geometry Lod"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return dayz_modding_tools["geo_done"]

    def execute(self, context):
        try:
            pass # Create_View_Geo.py Script Start
            import bpy
            bpy.ops.object.select_all(action='DESELECT')
            mem = bpy.context.scene.objects["Memory"]
            bpy.ops.mesh.primitive_cube_add()
            active = bpy.context.active_object
            active.name = "View Geometry"
            active.dimensions = mem.dimensions
            active.location = mem.location
            active.rotation_euler = mem.rotation_euler
            bpy.data.objects[active.name].armaObjProps.isArmaObject = True
            bpy.data.objects[active.name].armaObjProps.lod = '6.000e+15'
            bpy.ops.armatoolbox.create_components()
            pass # Create_View_Geo.py Script End
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create View Geometry Lod")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create View Geometry Lod")
        return self.execute(context)


class SNA_PT_Finalize_11237(bpy.types.Panel):
    bl_label = "Finalize"
    bl_idname = "SNA_PT_Finalize_11237"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'DayZ Modding Tools'
    bl_order = 0


    @classmethod
    def poll(cls, context):
        return dayz_modding_tools["show_finalize"]

    def draw_header(self, context):
        try:
            layout = self.layout
        except Exception as exc:
            print(str(exc) + " | Error in Finalize panel header")

    def draw(self, context):
        try:
            layout = self.layout
            col = layout.column(align=False)
            col.enabled = True
            col.alert = False
            col.scale_x = 1.0
            col.scale_y = 1.0
            col.label(text=r"Object Name",icon_value=0)
            col.prop(bpy.context.scene,'dz_object_name',icon_value=0,text=r"",emboss=True,)
            op = layout.operator("sna.create_config",text=r":::Crate Config:::",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.create_script",text=r":::Create Script:::",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.create_model_cfg",text=r"Done",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Finalize panel")


class SNA_OT_Create_Model_Cfg(bpy.types.Operator):
    bl_idname = "sna.create_model_cfg"
    bl_label = "Create_Model_CFG"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass # Create_CFG.py Script Start
            import bpy
            bpy.ops.object.select_all(action='DESELECT')
            name = bpy.context.scene.dz_object_name
            print(name)
            sections = ""
            count = 0
            Tabs = "\t\t\t"
            if bpy.context.scene.type_of_object == 'Inventory_Base':
                Object = bpy.context.scene.objects["0"]
                bpy.context.view_layer.objects.active = Object
                Object.select_set(True)
                for i in bpy.context.active_object.vertex_groups:  
                    count += 1
                    print(count)
                for i in bpy.context.active_object.vertex_groups:
                    if count > 1:
                        sections += Tabs + "\"" + i.name + "\"," + "\n"
                    if count == 1:
                        sections += Tabs + "\"" + i.name + "\""
                    count -= 1      
            if bpy.context.scene.type_of_object == 'Melee_Weapon':
                Object = bpy.context.scene.objects["View Pilot"]
                bpy.context.view_layer.objects.active = Object
                Object.select_set(True) 
                for i in bpy.context.active_object.vertex_groups:  
                    count += 1
                    print(count)
                for i in bpy.context.active_object.vertex_groups:
                    if count > 1:
                        sections += Tabs + "\"" + i.name + "\"," + "\n"
                    if count == 1:
                        sections += Tabs + "\"" + i.name + "\""
                    count -= 1 
            bpy.ops.object.select_all(action='DESELECT')
            filename = "model.cfg"
            if filename in bpy.data.texts:
                area = next(area for area in bpy.context.screen.areas if area.type == 'TEXT_EDITOR')
                area.spaces.active.text = bpy.data.texts['model.cfg']
                bpy.ops.text.unlink()
            if filename not in bpy.data.texts:
                bpy.data.texts.new(filename)
                area = next(area for area in bpy.context.screen.areas if area.type == 'TEXT_EDITOR')
                area.spaces.active.text = bpy.data.texts['model.cfg']
                #bpy.data.texts[filename].write(s)


                bpy.data.texts[filename].write("class CfgModels\n")
                bpy.data.texts[filename].write("{\n")


                bpy.data.texts[filename].write("\tclass Default\n")
                bpy.data.texts[filename].write("\t{\n")
                bpy.data.texts[filename].write("\t\tsections[] = {};\n")
                bpy.data.texts[filename].write("\t\tsectionsInherit="";\n")
                bpy.data.texts[filename].write("\t\tskeletonName = "";\n")
                bpy.data.texts[filename].write("\t};\n")


                bpy.data.texts[filename].write("\tclass " + " " + name + " : Default\n")
                bpy.data.texts[filename].write("\t{\n")
                bpy.data.texts[filename].write("\t\tsections[]=\n")
                bpy.data.texts[filename].write("\t\t{\n")
                bpy.data.texts[filename].write(sections + "\n")
                bpy.data.texts[filename].write("\t\t};\n")
                bpy.data.texts[filename].write("\t};\n")
                bpy.data.texts[filename].write("};\n")
                #area = next(area for area in bpy.context.screen.areas if area.type == 'TEXT_EDITOR')
                #area.spaces.active.text = bpy.data.texts['model.cfg']
            pass # Create_CFG.py Script End
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create_Model_CFG")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create_Model_CFG")
        return self.execute(context)


class SNA_OT_Create_Config(bpy.types.Operator):
    bl_idname = "sna.create_config"
    bl_label = "Create_Config"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create_Config")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create_Config")
        return self.execute(context)


class SNA_OT_Create_Script(bpy.types.Operator):
    bl_idname = "sna.create_script"
    bl_label = "Create_Script"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Create_Script")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Create_Script")
        return self.execute(context)


class SNA_OT_Reset_Tools(bpy.types.Operator):
    bl_idname = "sna.reset_tools"
    bl_label = "Reset Tools"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Reset Tools")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            dayz_modding_tools["type_chosen"] = False
            dayz_modding_tools["show_create_main"] = False
            dayz_modding_tools["show_create_mem"] = False
            dayz_modding_tools["mem_generated"] = False
            dayz_modding_tools["invview_created"] = False
            dayz_modding_tools["ce_center_created"] = False
            dayz_modding_tools["ce_radius_created"] = False
            dayz_modding_tools["range_start_created"] = False
            dayz_modding_tools["range_end_created"] = False
            dayz_modding_tools["throwing_impulse_created"] = False
            dayz_modding_tools["show_create_geo"] = False
            dayz_modding_tools["geo_created"] = False
            dayz_modding_tools["show_finalize"] = False
            dayz_modding_tools["geo_done"] = False
            bpy.context.scene.dz_object_name = r""
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Reset Tools")
        return self.execute(context)

def sn_prepend_menu_60A9D(self,context):
    try:
        layout = self.layout
        op = layout.operator("sna.reset_tools",text=r"Reset DayZ Tools",emboss=True,depress=False,icon_value=0)
    except Exception as exc:
        print(str(exc) + " | Error in Properties Ht Header when adding to menu")


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.dayz_modding_tools_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.dayz_modding_tools_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.dayz_modding_tools_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    bpy.types.Scene.type_of_object = bpy.props.EnumProperty(name='Type Of Object',description='',options=set(),items=[('Inventory_Base', 'Inventory_Base', ''), ('Melee_Weapon', 'Melee_Weapon', '')])
    bpy.types.Scene.number_of_lods = bpy.props.IntProperty(name='Number Of Lods',description='Number Of Lods To Make',subtype='NONE',options=set(),default=1,min=1,max=5)
    bpy.types.Scene.number_of_components = bpy.props.IntProperty(name='Number_Of_Components',description='',subtype='NONE',options=set(),default=2,min=0,max=100,soft_min=1,soft_max=100)
    bpy.types.Scene.simple_geometry = bpy.props.BoolProperty(name='Simple_Geometry',description='',options=set(),default=True)
    bpy.types.Scene.dz_object_name = bpy.props.StringProperty(name='DZ_Object_Name',description='',subtype='NONE',options=set(),default='')

def sn_unregister_properties():
    del bpy.types.Scene.type_of_object
    del bpy.types.Scene.number_of_lods
    del bpy.types.Scene.number_of_components
    del bpy.types.Scene.simple_geometry
    del bpy.types.Scene.dz_object_name


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_OT_Done_Creating_Object)
    bpy.utils.register_class(SNA_OT_Create_Resolution_Lods)
    bpy.utils.register_class(SNA_OT_Create_Dayz_Object)
    bpy.utils.register_class(SNA_PT_Create_DayZ_Object_B4F59)
    bpy.utils.register_class(SNA_PT_Create_Memory_Lod_8EC32)
    bpy.utils.register_class(SNA_OT_Create_Memory_Lod)
    bpy.utils.register_class(SNA_PT_Choose_Object_Type_E079D)
    bpy.utils.register_class(SNA_OT_Choose_Type)
    bpy.utils.register_class(SNA_PT_Create_Memory_Lod_8E26E)
    bpy.utils.register_class(SNA_PT_Create_Memory_Lod_468AA)
    bpy.utils.register_class(SNA_OT_Create_Invview)
    bpy.utils.register_class(SNA_OT_Create_Ce_Center)
    bpy.utils.register_class(SNA_OT_Inview_Done)
    bpy.utils.register_class(SNA_OT_Create_Range_End)
    bpy.utils.register_class(SNA_OT_Create_Throwing_Impulse)
    bpy.utils.register_class(SNA_OT_Create_Range_Start)
    bpy.utils.register_class(SNA_OT_Create_Ce_Radius)
    bpy.utils.register_class(SNA_PT_Create_Geometry_Lods_D9536)
    bpy.utils.register_class(SNA_OT_Geos_Done)
    bpy.utils.register_class(SNA_OT_Geo_Lod_Done)
    bpy.utils.register_class(SNA_OT_Create_Fire_Gometry_Lod)
    bpy.utils.register_class(SNA_OT_Create_Geometry_Lod)
    bpy.utils.register_class(SNA_OT_Create_View_Geometry_Lod)
    bpy.utils.register_class(SNA_PT_Finalize_11237)
    bpy.utils.register_class(SNA_OT_Create_Model_Cfg)
    bpy.utils.register_class(SNA_OT_Create_Config)
    bpy.utils.register_class(SNA_OT_Create_Script)
    bpy.utils.register_class(SNA_OT_Reset_Tools)
    bpy.types.PROPERTIES_HT_header.prepend(sn_prepend_menu_60A9D)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.types.PROPERTIES_HT_header.remove(sn_prepend_menu_60A9D)
    bpy.utils.unregister_class(SNA_OT_Reset_Tools)
    bpy.utils.unregister_class(SNA_OT_Create_Script)
    bpy.utils.unregister_class(SNA_OT_Create_Config)
    bpy.utils.unregister_class(SNA_OT_Create_Model_Cfg)
    bpy.utils.unregister_class(SNA_PT_Finalize_11237)
    bpy.utils.unregister_class(SNA_OT_Create_View_Geometry_Lod)
    bpy.utils.unregister_class(SNA_OT_Create_Geometry_Lod)
    bpy.utils.unregister_class(SNA_OT_Create_Fire_Gometry_Lod)
    bpy.utils.unregister_class(SNA_OT_Geo_Lod_Done)
    bpy.utils.unregister_class(SNA_OT_Geos_Done)
    bpy.utils.unregister_class(SNA_PT_Create_Geometry_Lods_D9536)
    bpy.utils.unregister_class(SNA_OT_Create_Ce_Radius)
    bpy.utils.unregister_class(SNA_OT_Create_Range_Start)
    bpy.utils.unregister_class(SNA_OT_Create_Throwing_Impulse)
    bpy.utils.unregister_class(SNA_OT_Create_Range_End)
    bpy.utils.unregister_class(SNA_OT_Inview_Done)
    bpy.utils.unregister_class(SNA_OT_Create_Ce_Center)
    bpy.utils.unregister_class(SNA_OT_Create_Invview)
    bpy.utils.unregister_class(SNA_PT_Create_Memory_Lod_468AA)
    bpy.utils.unregister_class(SNA_PT_Create_Memory_Lod_8E26E)
    bpy.utils.unregister_class(SNA_OT_Choose_Type)
    bpy.utils.unregister_class(SNA_PT_Choose_Object_Type_E079D)
    bpy.utils.unregister_class(SNA_OT_Create_Memory_Lod)
    bpy.utils.unregister_class(SNA_PT_Create_Memory_Lod_8EC32)
    bpy.utils.unregister_class(SNA_PT_Create_DayZ_Object_B4F59)
    bpy.utils.unregister_class(SNA_OT_Create_Dayz_Object)
    bpy.utils.unregister_class(SNA_OT_Create_Resolution_Lods)
    bpy.utils.unregister_class(SNA_OT_Done_Creating_Object)